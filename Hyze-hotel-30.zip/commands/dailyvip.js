const db = require('quick.db') // Puxando a livraria quick.db
const Discord = require('discord.js') // puxando a livraria Discord.js

exports.run = async (client, message, args) => {
    if (!message.member.permissions.has("SEND_TTS_MESSAGES"))
    return message.reply(
    "Apenas usuários vips podem usar esse comando."
    );


    function convertMilliseconds(ms) {
        const seconds = ~~(ms/1000)
        const minutes = ~~(seconds/60)
        const hours = ~~(minutes/60)
        const days = ~~(hours/24)
      
        return { days, hours: hours%24, minutes: minutes%60, seconds: seconds%60 }
      }
      let user = message.author;
      let timeout = 86400000 // O tempo que poderá ser utilizado o comando, (24 horas em mili segundos)
       let saldo = Math.floor(Math.random() * 6000) + 500; // Sistema randomico que será entrem 1500 a 500 que será adicionado.

        let daily = db.fetch(`daily_${message.guild.id}_${user.id}`);
    
       if (daily !== null && timeout - (Date.now() - daily) > 0) { // pegando o 'daily' e verificando se o timeout expirou
        let time = convertMilliseconds(timeout - (Date.now() - daily)); // definindo os tempos na variável 'time'
           
        const embed2 = new Discord.MessageEmbed()
  
        .setDescription(`Você já resgatou o daily de hoje.\nTente novamente em: **${time.hours}h ${time.minutes}m ${time.seconds}s**`)
        .setThumbnail("https://media.discordapp.net/attachments/856587370362568734/856706359168729118/VIP.PNG.png")
        .setColor("#ff4747")


           message.reply(embed2)
       } else { // Se o tempo ja tiver passado ele retornara:
          

        const embed = new Discord.MessageEmbed()
  
        .setDescription(`Você recebeu:\n **R$ ${saldo}** no diário de vip.`)
        .setThumbnail("https://media.discordapp.net/attachments/856587370362568734/856706359168729118/VIP.PNG.png")
        .setColor("GREEN")

            message.channel.send(embed)
    
        db.add(`money_${message.guild.id}_${user.id}`, saldo) // Adicionando o dinheiro para o usuario
        db.set(`daily_${message.guild.id}_${user.id}`, Date.now()) // Adicionando o tempo na DB
        }
    }
exports.help = {
    name: 'daily',
    aliases: ['diário', 'diario']
}
