const Discord = require("discord.js");
const config = require("../config.json");

module.exports.run = async (client, message, args) => {

      let avatar = message.author.avatarURL({ dynamic: true, format: "gif", size: 1024 });
            if (!message.member.hasPermission("MANAGE_MESSAGES")) {
        const embed = new Discord.MessageEmbed()
        .setDescription(`${message.author}, VocÃª nÃ£o tem permissÃ£o de __**MENAGE_MESSAGES**__ para usar este comando.`)
        return message.channel.send(embed);
      }
    message.delete();
    message.channel.createOverwrite(message.guild.id, {
        SEND_MESSAGES: false,
        VIEW_CHANNEL: true
    })
    const lock = new Discord.MessageEmbed()
    .setTitle(':lock: CHAT TRANCADO!')
    .setDescription(`Este chat foi mutado. para desmutar use o comando ${config.prefix}unlock.`)
    .addField(':unlock: Destrancar:', `${config.prefix}unlock`, true)
    .addField(':lock: Trancado Por:', `${message.author}`, true)
    .setTimestamp()
    .setThumbnail(avatar)
    .setColor('#ffff00')
    
    message.channel.send(lock).then(msg => {
    msg.react(':lock:').then(r => {
    msg.react(':lock:').then(r => {
  })
  })
    const geralFilter = (reaction, user) => reaction.emoji.name === ':lock:' && user.id === message.author.id;
    const geral2Filter = (reaction, user) => reaction.emoji.name === ':lock:' && user.id === message.author.id;
    const geral = msg.createReactionCollector(geralFilter);const geral2 = msg.createReactionCollector(geral2Filter);

geral.on('collect', r2 => {
    const embed = new Discord.MessageEmbed()
    .setTitle(':unlock: CHAT DESTRANCADO!')
    .setDescription(`Este chat foi desmutado. para mutar use o comando ${config.prefix}lock.`)
    .addField(':lock: Trancar:', `${config.prefix}lock`, true)
    .addField(':unlock: Destrancado Por:', `${message.author}`, true)
    .setColor('#ffff00')
    .setTimestamp()
    .setThumbnail(avatar)
message.channel.createOverwrite(message.guild.id, {
        SEND_MESSAGES: true,
        VIEW_CHANNEL: true
    })
msg.edit(embed);
})
geral2.on('collect', r2 => {
    const embed = new Discord.MessageEmbed()
    .setTitle(':lock: CHAT TRANCADO!')
    .setDescription(`Este chat foi mutado. para desmutar use o comando ${config.prefix}unlock,`)
    .addField(':unlock: Destrancar:', `${config.prefix}unlock`, true)
    .addField(':lock: Trancado Por:', `${message.author}`, true)
    .setTimestamp()
    .setThumbnail(avatar)
    .setColor('#ffff00')
message.channel.createOverwrite(message.guild.id, {
        SEND_MESSAGES: false,
        VIEW_CHANNEL: true
    })
    msg.edit(embed);
    }) 
    
    })
}