const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async (client, message, args) => {
     
    let embed = new Discord.MessageEmbed()
    .setDescription("**Loja Hyze**\n\n150 Diamantes: **36000 moedas** [.buy diamantes]\n\n**Outros Items**\n\nSofá custom: **600 moedas** [.buy sofá]\nserpa custom: **800 moedas** [.buy serpa]\nemblema: **1200 moedas** [.buy emblema]")
    .setColor("#FFFF00")
    message.channel.send(embed)




}


module.exports.help = {
  name:"store",
  aliases: ["st"]
}