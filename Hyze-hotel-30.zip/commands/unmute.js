const { Message } = require('discord.js')

module.exports=  {
    name : 'unmute', 
    /**
     * @param {Message} message
     */
    run : async(client, message, args) => {
        const Member = message.mentions.members.first() || message.guild.members.cache.get(args[0])

if (!message.member.hasPermission('ADMINISTRATOR')) return message.reply("Não tem permissão para esse comando!")
    if (!message.guild.me.hasPermission('ADMINISTRATOR')) return message.reply("Não tenho permissão administrativas!")


        if(!Member) return message.channel.send('Membro não encontrado.')

        const role = message.guild.roles.cache.find(r => r.name.toLowerCase() === 'silenciado');

        await Member.roles.remove(role)

        message.channel.send(`${Member.displayName} agora não está mas mudo.`)
    }
}