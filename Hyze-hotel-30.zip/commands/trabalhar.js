const db = require('quick.db') // Puxando a DataBase. *Instale utilizando: npm i quick.db --save

exports.run = async (client, message, args) => {

  function convertMilliseconds(ms) {
    const seconds = ~~(ms/1000)
    const minutes = ~~(seconds/60)
    const hours = ~~(minutes/60)
    const days = ~~(hours/24)
  
    return { days, hours: hours%24, minutes: minutes%60, seconds: seconds%60 }
  }
    
// Lista funções de um Programador irá fazer
let programmer = ['BOT para discord.js', 'aplicativo para celular', 'site profissional para seu bot', 'plataforma de stream', 'comando para seu bot', 'criou um aplicativo para ver o tempo', 'um site para sua empresa']
let miner = ['Ouro', 'Diamante', 'Aluminio', 'Rubi', 'Safira', 'Esmeralda', 'Ametista', 'Topázio', 'Turqueza', 'Quartzo'] 

let vendendor = ['Coca cola', 'biscoito', 'arroz', 'café', 'carne', 'feijão', 'macarrão', 'bombom', 'nutela', 'pipoca', 'sabonete', 'detergente']

let programa = ['Garota de Programa']

let traficante = ['Maconha', 'crack', 'cocaína', 'Loló', 'Lança Perfume', 'LSD', 'heroína', 'chá de cogumelo']
let Striper = ['Striper']
let user = message.author;
    let quantia = Math.floor(Math.random() * 350) + 150; // Definindo quanto o usuário pode ganhar 
    let trabalho = await db.get(`work_${message.guild.id}_${user.id}`); // Puxando da DataBase o 'work', que vai definir que o mesmo trabalhou

    let timeout = 606060;

    if (trabalho !== null && timeout - (Date.now() - trabalho) > 0) { // Puxando o trabalho e iremos dar o timeout
     let time = convertMilliseconds(timeout - (Date.now() - trabalho)); // Definindo que 'time' será os tempos
      
      message.channel.send(`Você ja trabalhou recentemente.\nVocê podera trabalhar novamente em: **${time.minutes}m ${time.seconds}s**`)
   
     } else {
        let emprego = await db.get(`emprego_${message.guild.id}_${user.id}`) // Puxando o 'emprego', que utilizamos como emprego
        if (emprego === null) { // Caso o 'emprego' do usuário seja 'null', ou seja, zero, iremos avisar que ele precisa de um emprego
          return message.reply(`Para poder trabalhar você deve possuir um emprego, para arrumar um emprego use: \`.emprego\`.`)
        } else {
          
        } // Caso o usuário seja um Programador, que definimos como Um (1)
        if (emprego === 1) {                                      // Puxando a lista que criamos no início
          message.channel.send(`💻 Você programou um: **${programmer[Math.floor(Math.random() * programmer.length)]}** na venda você recebeu: **R$ ${quantia}**`)
          db.add(`money_${message.guild.id}_${user.id}`, quantia) // setando a 'quantia' de dinheiro por trabalhar hoje
          db.set(`work_${message.guild.id}_${user.id}`, Date.now()) // Setando o timeout que criamos acima, no 'work', salvando na DataBase 
       } // Caso o usuário seja um Programador, que definimos como Dois (2)
       
        if (emprego === 2) {                                     // Puxando a lista que criamos no início
          message.channel.send(`⛏️ Você minerou um: **${miner[Math.floor(Math.random() * miner.length)]}** na venda você recebeu: **R$ ${quantia}**`)
          db.add(`money_${message.guild.id}_${user.id}`, quantia) // setando a 'quantia' de dinheiro por trabalhar hoje
          db.set(`work_${message.guild.id}_${user.id}`, Date.now()) // Setando o timeout que criamos acima, no 'work', salvando na DataBase
       }

       if (emprego === 3) {                                     // Puxando a lista que criamos no início
        message.channel.send(`🛒 Você vendeu: **${vendendor[Math.floor(Math.random() * vendendor.length)]}** e com a venda você recebeu: **R$ ${quantia}**`)
        db.add(`money_${message.guild.id}_${user.id}`, quantia) // setando a 'quantia' de dinheiro por trabalhar hoje
        db.set(`work_${message.guild.id}_${user.id}`, Date.now()) // Setando o timeout que criamos acima, no 'work', salvando na DataBase
     }

     if (emprego === 4) {                                     // Puxando a lista que criamos no início
      message.channel.send(`💋 Você trabalhou de: **${programa[Math.floor(Math.random() * programa.length)]}** e com a prostituição você recebeu: **R$ ${quantia}**`)
      db.add(`money_${message.guild.id}_${user.id}`, quantia) // setando a 'quantia' de dinheiro por trabalhar hoje
      db.set(`work_${message.guild.id}_${user.id}`, Date.now()) // Setando o timeout que criamos acima, no 'work', salvando na DataBase
   }

    if (emprego === 5) {                                     // Puxando a lista que criamos no início
      message.channel.send(`🚬 Você trabalhou como traficante e vendeu: **${traficante[Math.floor(Math.random() * traficante.length)]}** e com o trafico você recebeu: **R$ ${quantia}**`)
      db.add(`money_${message.guild.id}_${user.id}`, quantia) // setando a 'quantia' de dinheiro por trabalhar hoje
      db.set(`work_${message.guild.id}_${user.id}`, Date.now()) // Setando o timeout que criamos acima, no 'work', salvando na DataBase
   }

   if (emprego === 6) {                                     // Puxando a lista que criamos no início
    message.channel.send(`👯 Você trabalhou como: **${Striper[Math.floor(Math.random() * Striper.length)]}** e com o StripeTease ganhou: **R$ ${quantia}**`)
    db.add(`money_${message.guild.id}_${user.id}`, quantia) // setando a 'quantia' de dinheiro por trabalhar hoje
    db.set(`work_${message.guild.id}_${user.id}`, Date.now()) // Setando o timeout que criamos acima, no 'work', salvando na DataBase
 }

   
  
 }

}

exports.help = {
    name: 'trabalhar',
    aliases: ['work']
}
