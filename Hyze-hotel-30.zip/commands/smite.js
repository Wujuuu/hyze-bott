module.exports.run = (bot, message, args) => {
    // ⚡ 🌩
    let user = message.mentions.users.first() ? message.mentions.users.first() : message.author;
    let member = message.guild.member(user);
  
    message.channel.send(`🌩 Uma nuvem de raios aparece...`).then(m => {
      setTimeout(function() {
        if (user.id == message.author.id) {
          m.edit(`⚡ Oh não parece ${message.author} atingiu a si mesmo com iluminação!`);
        } else {
          m.edit(`⚡ ${message.author.username} jogou um raio em ${member} e ela ficou atordoada!`);
        }
        message.delete({ timeout: 1000 });
      }, 3000);
    });
  };
  
  module.exports.help = {
    name: "smite",
    usage: ``,
    information: "Makes a wild cloud appear and smites the valid user."
  };
  
  module.exports.settings = {
    permission: "All",
    deleteresponder: true,
    category: "Fun"
  };