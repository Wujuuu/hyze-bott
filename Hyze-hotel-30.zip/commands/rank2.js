const Discord = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args,) => {

    const user = message.guild.member(message.mentions.users.first());

    let bank = db.all().filter(data => data.ID.startsWith(`bank_${message.guild.id}`)).sort((a, b) => b.data - a.data);
    
    let bank1;
    
    if(bank.length > 10){
        bank1 = 10
    }else{
        bank1 = bank.length
    
    }
    let content = "";
    
    for(let i = 0; i < bank.length; i++) {
        let user = client.users.cache.get(bank[i].ID.split('_')[2])

        content += `${i+1}. ${user} - \$${bank[i].data} \n`

    }

    const embed = new Discord.MessageEmbed()
    .setTitle(`:bank: **|** Rank Bancario - ${message.guild.name}`)
    .setDescription(content)
    .setColor("BLUE")
    .setThumbnail('https://media.discordapp.net/attachments/856587370362568734/856941415673757806/banco.png')
    .setFooter(`Rank Bancario do Servidor!`)
    .setTimestamp();

    message.channel.send(`${message.author}`, embed);
}   