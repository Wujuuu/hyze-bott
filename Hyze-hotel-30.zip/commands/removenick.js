const { Client, Message, MessageEmbed } = require('discord.js');

module.exports = {
    name: 'resetnick',
    /** 
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
run: async (client,message,args) => {
const member = message.mentions.members.first();

if (!member) return message.reply("por favor marque um usuario valido!");

try{
  member.setNickname(null);
}catch (err) {
  message.reply(
    "você não tem permissão " + member.toString()+ "nickname"
  );
}
message.channel.send(`prontinho ${message.author} nick resetado`)
},
};