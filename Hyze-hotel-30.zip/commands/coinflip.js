const slotItems = ["cara", "coroa"];
const Discord = require("discord.js")
const db = require("quick.db");

exports.run = async (client, message, args) => {

    
    let moneyhelp = new Discord.MessageEmbed()
    .setColor("RED")
    .setDescription(`❌ Especifique o flip, cara ou coroa e o valor para ser jogado`);

    let moneyhel2 = new Discord.MessageEmbed()
    .setColor("GREEN")
    .setDescription(`❌ Especifique o flip, cara ou coroa!`);

    let moneymore = new Discord.MessageEmbed()
    .setColor("GREEN")
    .setDescription(`❌ Você está apostando mais do que você tem`);

    let user = message.author;
    let money = parseInt(args[1]);
    let moneydb = await db.fetch(`money_${message.guild.id}_${user.id}`)
    let win = false;


    if (!money) return message.channel.send(moneyhelp);
    if (money > moneydb) return message.channel.send(moneymore);


    let number = []
    for (i = 0; i < 3; i++) { number[i] = Math.floor(Math.random() * slotItems.length); }

    if (number[0] == number[1] && number[1] == number[2]) { 
        money *= 3
        win = true;
    } else if (number[0] == number[1] || number[0] == number[2] || number[1] == number[2]) { 
        money *= 3
        win = true;
    }
    if (win) {
  var array1 = ["cara", "coroa"];

  var rand = Math.floor(Math.random() * array1.length);

  if (!args[0] || (args[0].toLowerCase() !== "cara" && args[0].toLowerCase() !== "coroa")) {
    message.reply(moneyhel2);
  } 
else if (args[0].toLowerCase() == array1[rand]) {

    let ganhou = new Discord.MessageEmbed()
    .setColor("GREEN")
    .setDescription(`✅ Deu ` + array1[rand] + `, Você ganhou ${money} moedas!`)
    db.add(`money_${message.guild.id}_${user.id}`, money)
    message.channel.send(ganhou);
  } 
else if (args[0].toLowerCase() != array1[rand]) {

    let perdeu = new Discord.MessageEmbed()
    .setColor("RED")
    .setDescription(`❌ Deu ` + array1[rand] + `, você perdeu ${money} dessa vez!`)
    db.subtract(`money_${message.guild.id}_${user.id}`, money)
    message.channel.send(perdeu);
  }
}
};