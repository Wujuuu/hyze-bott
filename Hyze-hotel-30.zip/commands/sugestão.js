const  { MessageEmbed } = require("discord.js")

module.exports = {
name: "Sugestão",
run: async (client, message, args) => {

let dono = client.users.cache.get("428688031831293952")//meu id
let canal = client.channels.cache.get("859602057862709289")//id do canal
let autor = message.author;
let server = message.guild;
let bot = client.user;
let bug = args.join(" ")


if(!bug) return message.channel.send("**Digite sua sugestão.**")
if(bug.length > 1000) return message.channel.send("**me dê uma sugestão menor para ser enviada!**")

//console
console.log(`Sugestão\Sugestão: ${bug}\nUser: ${autor.tag}(${autor.id})\nServidor: ${server.name}`)

//canal
const embed2 = new MessageEmbed()
.setAuthor(`Sugestão ${bot.username}`, bot.displayAvatarURL())
.setFooter(`Sugestão ${server.name}`)
.setTimestamp()
.addField("Autor:", `${autor.tag}(${autor.id})`)
.addField("Server", `${server.name}`)
.addField("Sugestão", `${bug}`)
canal.send(embed2)

//dono
const embed1 = new MessageEmbed()
.setAuthor(`Sugestão ${bot.username}`, bot.displayAvatarURL())
.setFooter(`Sugestão ${server.name}`)
.setColor("#ffff00")
.setTimestamp()
.addField("Autor:", `${autor.tag}(${autor.id})`)
.addField("Server", `${server.name}`)
.addField("Sugestão", `${bug}`)
dono.send(embed1)

//mensagem no canal que foi executado o comando
message.channel.send({embed: {
description: `${autor} Sugestão enviada para a equipe com sucesso!`,
color: "#ffff00"
}})

//envia a mensagem na dm do autor 
message.author.send({embed2: {
description: `${autor} Sugestão enviada para a equipe com sucesso!`,
color: "#ffff00"
}})
}
}