const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {

let canal = client.channels.cache.get("853425990876528680")


let autor = message.author;
let server = message.guild;
let bug = args.join(" ")


if(!bug) return message.channel.send("**Ultilize \`.ban @usuario <motivo>\` para banir um usuário.**")

        if(!message.member.hasPermission("BAN_MEMBERS")) return message.channel.send({embed: {color: "#ff0000", description: ":rotating_light: Você não tem permissão para utilizar este comando!"}})

        const usuario = message.mentions.members.first()
    
        const motivo = args.slice(1).join(" ");

        if(!usuario.bannable) return message.channel.send({embed: {color: "#ff0000", description: ":rotating_light: Eu não tenho permissão para banir este usuário!"}})

        const embed = new Discord.MessageEmbed()
        .setTitle("Novo Banimento!")
        .setColor("#ffff00")
        .addField(`Usuário:`, `${usuario}`)
        .addField(`Autor:`, `${message.author}`)
        .addField(`Motivo:`, `${motivo}`)
        message.channel.send(embed);


        const pv = new Discord.MessageEmbed()
        .setTitle("Você foi banido!")
        .setColor("#ffff00")
        .addField("Autor:", `${message.author}`)
        .addField("Motivo:", `${motivo}`)
        .setTimestamp();
        usuario.send(pv).catch(console.error);
        usuario.ban();

      const log1 = new Discord.MessageEmbed()
        .setTitle("Hyze Ban Log")
        .setColor("#ffff00")
        .addField(`Usuário Banido:`, `${usuario}`)
        .addField("Autor:", `${message.author}`)
        .addField("Motivo:", `${motivo}`)
        .setTimestamp();
        canal.send(log1).catch(console.error);

    }
