const db = require("quick.db") 
const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {

    if (!message.member.permissions.has("SEND_TTS_MESSAGES"))
    return message.reply(
    "Apenas usuários vips podem usar esse comando."
    );


    function convertMilliseconds(ms) {
        const seconds = ~~(ms/1000)
        const minutes = ~~(seconds/60)
        
        return { minutes: minutes%60, seconds: seconds%60 }
      }

 const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
 let user = message.author;
 let author = await db.fetch(`gf_${message.guild.id}_${user.id}`)

 let timeout = 606060;
    
 if (author !== null && timeout - (Date.now() - author) > 9000) {
    let time = convertMilliseconds(timeout - (Date.now() -  author));

    let gf1 = new Discord.MessageEmbed() 
            .setColor("RED")
            .setTitle(`☎️ • GF`)
            .setDescription(`**${member.user.tag}**, você precisa esperar para poder usar o gf novamente, tente novamente em \`${time.minutes} minutos, ${time.seconds} segundos\`.`)
            .setTimestamp();

        message.channel.send(gf1)
      } else {

    let fish = [
    "☎️`(Gf)`",

    ]

    let nome = [
        "🧑‍🦱`(Andre)`",
        "👨`(joão)`",
        "👨‍🦱`(Fernando)`",
    
        ]

    let fishresult = Math.floor((Math.random() * fish.length));
    let nomeresult = Math.floor((Math.random() * nome.length));
    let amount = Math.floor(Math.random() * 550) + 250;
        if (!args[0]) {

            let gf = new Discord.MessageEmbed() 
            .setColor("GREEN")
            .setTitle(`☎️ • GF`)
            .setDescription(`${member.user.tag} fez ${fish[fishresult]} com o **${nome[nomeresult]}** e se divertiram muito 😏.`)
            .setFooter(`Ganhou ${amount} moedas com o gf.`)
            .setTimestamp();
        message.channel.send(gf)
    db.add(`money_${message.guild.id}_${user.id}`, amount)
    db.set(`gf_${message.guild.id}_${user.id}`, Date.now())
    }
   }
    }
module.exports.help = {
    name:"fish",
    aliases: []
}