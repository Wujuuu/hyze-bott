const  { MessageEmbed } = require("discord.js")

exports.run = async (client,message,args) => {

let canal = client.channels.cache.get("849715706344898560")//id do canal
let autor = message.author;
let server = message.guild;
let bot = client.user;
let bug = args.join(" ")




    if (!message.member.roles.cache.has('Rapid Admin') && !message.member.hasPermission("ADMINISTRATOR")) {
		return message.channel.send("Você não tem permissão para executar esse comando!");
    }
    
    const channel  = message.mentions.channels.first() || message.channel;
    const roles    = message.guild.roles.cache;
    const everyone = roles.find(role => role.name === "@everyone");

    await channel.overwritePermissions([
        {
            id: everyone,
            allow: ["SEND_MESSAGES"]
        }
    ]);

//log
const embed = new MessageEmbed()
    .setTitle(`Hyze Hotel`)
    .setColor("#ffff00")
    .setDescription(`Chat <#${channel.id}> foi desbloqueado.`)
    .addField("Autor:", message.author)
    .setTimestamp();
    canal.send(embed)

//chat atual
    const msg = new MessageEmbed()
        .setTitle(`Hyze Hotel`)
    .setColor("#ffff00")
    .setDescription(`**Os membros agora podem conversar no chat** <#${channel.id}>!`)
    .addField("Autor:", message.author)
    .setTimestamp();
    message.channel.send(msg);
};