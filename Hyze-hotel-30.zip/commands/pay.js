const Discord = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args) => {
    let user = message.mentions.members.first() 

    let member = db.fetch(`money_${message.guild.id}_${message.author.id}`)

    let embed1 = new Discord.MessageEmbed()
    .setTitle("💵 **|** Transferencia")
    .setColor("BLUE")
    .setThumbnail('https://media.discordapp.net/attachments/856587370362568734/856939044930715658/Pay.png')
    .setDescription(`🚫 **|** Mencione alguem para pagar!`)
    .setFooter("Transferencia invalida!!")
    .setTimestamp();
    if (!user) {
        return message.channel.send(`${message.author}`, embed1)
    }
    let embed2 = new Discord.MessageEmbed()
    .setTitle("💵 **|** Transferencia")
    .setColor("BLUE")
    .setThumbnail('https://media.discordapp.net/attachments/856587370362568734/856939044930715658/Pay.png')
    .setDescription(`🚫 **|** Coloque o valor do pagamento!`)
    .setFooter("Transferencia invalida!!")
    .setTimestamp();
  
    if (!args[1]) {
        return message.channel.send(`${message.author}`, embed2)
    }
    let embed4 = new Discord.MessageEmbed()
    .setTitle("💵 **|** Transferencia")
    .setColor("BLUE")
    .setThumbnail('https://media.discordapp.net/attachments/856587370362568734/856939044930715658/Pay.png')
    .setDescription(`🚫 **|** Você não tem moedas suficiente para realizar o pagamento!`)
    .setFooter("Transferencia invalida!!")
    .setTimestamp();

    if (member < args[1]) {
        return message.channel.send(`${message.author}`, embed4)
    }
    let embed5 = new Discord.MessageEmbed()
    .setTitle("💵 **|** Transferencia")
    .setColor("BLUE")
    .setThumbnail('https://media.discordapp.net/attachments/856587370362568734/856939044930715658/Pay.png')
    .setDescription(`🚫 **|** Você tem que colocar um valor maior que **0** para realizar o pagamento!`)
    .setFooter("Transferencia invalida!!")
    .setTimestamp();

    if(args[1] < 0) {
        return message.channel.send(`${message.author}`, embed5)
    }
    let embed7 = new Discord.MessageEmbed()
    .setTitle("💵 **|** Transferencia")
    .setColor("BLUE")
    .setThumbnail('https://media.discordapp.net/attachments/856587370362568734/856939044930715658/Pay.png')
    .setDescription(`🚫 **|** Você tem que colocar um valor numerico para realizar o pagamento!`)
    .setFooter("Transferencia invalida!!")
    .setTimestamp();

    if (isNaN(args[1])){
        return message.channel.send(`${message.author}`, embed7)
    }
    let embed6 = new Discord.MessageEmbed()
    .setTitle("💵 **|** Transferencia")
    .setColor("BLUE")
    .setThumbnail('https://media.discordapp.net/attachments/856587370362568734/856939044930715658/Pay.png')
    .setDescription(`💵 Você pagou o ${user} com **R$${args[1]}**!`)
    .setFooter("Transferencia bem sucedida!!")
    .setTimestamp();

    message.channel.send(`${message.author}`, embed6)
    db.add(`money_${message.guild.id}_${user.id}`, args[1])
    db.subtract(`money_${message.guild.id}_${message.author.id}`, args[1])
}   