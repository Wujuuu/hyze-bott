const client = require('nekos.life');
const Discord = require('discord.js')
const neko = new client();
module.exports = {
  name: "baka",
  category: "emoções",
  description: "idiota",
  usage: "[command] or [command] + [user]",
  run: async (client, message, args) => {

      if (!message.member.permissions.has("SEND_TTS_MESSAGES"))
      return message.reply(
      "Apenas usuários vips podem usar esse comando."
      );

        const user = message.mentions.users.first();
        if(!user)
        return message.reply('Mencione alguém, para você chama-lo de idiota');

        async function work() {
        let owo = (await neko.sfw.baka());

        const baka = new Discord.MessageEmbed()
        .setTitle("idiota!")
        .setDescription((" SEU IDIOTA!!! " + user.toString()))
        .setImage(owo.url)
        .setColor(`RED`)
        .setURL(owo.url);
        message.channel.send(baka);

}

      work();
}
};