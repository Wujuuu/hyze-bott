const Discord = require("discord.js");
const Levels = require("discord-xp");
const db = require("quick.db");

exports.run = async (client, message, args) => {


    if (!message.member.permissions.has("SEND_TTS_MESSAGES"))
    return message.reply(
    "Apenas usuários vips podem usar esse comando."
    );


function convertMilliseconds(ms) {
        const seconds = ~~(ms/1000)
        const minutes = ~~(seconds/60)
        const hours = ~~(minutes/60)
        const days = ~~(hours/24)
      
        return { days, hours: hours%24, minutes: minutes%60, seconds: seconds%60 }
      }
      
    

    let autor = message.author;
    let user = message.author;


    let timeout = 1980000;

    let daily = await db.fetch(`error_${message.guild.id}_${autor.id}`);

    if (daily !== null && timeout - (Date.now() - daily) > 0) {


 let time = convertMilliseconds(timeout - (Date.now() - daily));
      
        let timeEmbed = new Discord.MessageEmbed()
        .setColor("#4B0082")
        .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/859577124552441906/cripta.png?width=537&height=559')
        .setDescription(` Você tentou passar pela a cripta a pouco tempo!\n\nTente novamente daqui a **${time.hours}h ${time.minutes}m ${time.seconds}s**`);
        
        message.channel.send(`${autor}`, timeEmbed);
    } else {
        
        let sorte = Math.floor(Math.random() * 4) + 1;
        
        if(sorte == 2) {
            
            let amount = Math.floor(Math.random() * 150) + 8;
            
            let moneyEmbed = new Discord.MessageEmbed()
            .setTitle("Sua Cripta falhou!")
            .setColor("RED")
            .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/859577124552441906/cripta.png?width=537&height=559')
            .setDescription(`Você tentou passar pela a cripta e não se saiu muito bem!\nE você perdeu um total de **R$${amount}**!`)
            .setFooter(`estatistica da cripta`);

            message.channel.send(`${autor}`, moneyEmbed);
            db.subtract(`money_${message.guild.id}_${autor.id}`, amount);
            db.set(`error_${message.guild.id}_${autor.id}`, Date.now());
        }else{

            let historia = new Discord.MessageEmbed()
            .setTitle("Cripta")
            .setColor("#7FFFD4")
            .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/859577124552441906/cripta.png?width=537&height=559')
            .setDescription("A Cripta Dos mortos vivos. Um mal ancestral agita-se nas entranhas do mundo, e a terra definha. O temível feiticeiro Wuju foi despertado, e está disposto a alcançar seus sonhos de morte e tirania. Ele é vulnerável apenas à sua própria espada, perdida há muito tempo, e tem uma impressionante gama de poderes.")
            .setFooter(`reaja com 🧺, para poder ver seu loot.`);


            message.channel.send(historia).catch(err => message.channel.send(erros)).then(async msg => {
                await msg.react('🧺')

           const loot = (reaction, user) => reaction.emoji.name === '🧺' && user.id === message.author.id;

           const LootL = msg.createReactionCollector(loot)
        
            
            const randomAmountOfXp = Math.floor(Math.random() * 15) + 20;
            

            Levels.appendXp(message.author.id, message.guild.id, randomAmountOfXp);
    
               const user = await Levels.fetch(message.author.id, message.guild.id);

            let amount = Math.floor(Math.random() * 450) + 550;


            
            LootL.on('collect', r => {

          const looot = new Discord.MessageEmbed()
             .setTitle("Loot da cripta:")
             .setColor("PINK")
             .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/859577124552441906/cripta.png?width=537&height=559')
             .setDescription(`**Usuário:**\n${autor}\n\n💰 **Dinheiro ganho:**\n**${amount}.**\n\n<:unnamed:859596024334778398> **Xp ganho:** \n${randomAmountOfXp} experiência.\n\n<:levelup:859596052611989524> **level:** \n      ${user.level}.`)
             .setFooter(`estatistica da cripta`);
            
             msg.edit(looot)
            db.add(`money_${message.guild.id}_${autor.id}`, amount);
            db.set(`error_${message.guild.id}_${autor.id}`, Date.now());


        })
    })
}
}
};
