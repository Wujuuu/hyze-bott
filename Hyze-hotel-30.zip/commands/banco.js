const Discord = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args) => {
    let user = client.users.cache.get(args[0]) || message.mentions.users.first() ||  message.author;

    let bank = db.fetch(`bank_${message.guild.id}_${user.id}`)
    if(bank === null) bank = 0;

    const embed = new Discord.MessageEmbed()
    .setColor("BLUE")
    .setThumbnail('https://media.discordapp.net/attachments/856587370362568734/856929595031027722/1115420.png')
    .setTitle(":bank: **|** Conta Bancaria")
    .setDescription(`**${user.username}**, veja as informações da sua conta bancaria:` +
    `\n:bank: Dinheiro na conta: **R$${bank}**`)
    .setFooter("Informações da sua conta!")
    .setTimestamp();

    message.channel.send(`${user}`, embed);
}