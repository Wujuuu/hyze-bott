const Discord = require("discord.js");
const db = require('quick.db');

exports.run = async (client, message, membro, args) => {

  let canal = client.channels.cache.get("856616439444406354")

  let user = message.author;
  
  let dinheiro = await db.get(`money_${message.guild.id}_${user.id}`)
  if (dinheiro === null) dinheiro = 0;
  
let embed = new Discord.MessageEmbed()

  .setTitle(`Cargos - Hyze \n💎 **Vips:**`)
  .setDescription(`

:small_orange_diamond: - 150k | 5 dias
:small_blue_diamond: - 350k | 10 dias
:large_orange_diamond: - 500k | 20 dias
:large_blue_diamond:  - 800k | 1 mês
  
  `)
  .addField (`**Info:**`, `Para comprar o \`cargo\` basta clicar\nno emoji de acordo com o cargo\n**Reaja ⏩ para poder ir para página 2**.`)
  .setColor('#ff4747')
  .setThumbnail('https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503')

message.channel.send({embed}).then(msg=>{
      msg.react('🔸')
      msg.react('🔹')
      msg.react('🔶')
      msg.react('🔷')
      msg.react('⏩')
      msg.react('↩')
  
message.delete(embed)
  
  const vipfilter = (reaction, user) => reaction.emoji.name === '🔸' && user.id === message.author.id;
  const vipL = msg.createReactionCollector(vipfilter);
  
  vipL.on('collect', r2 => { 
    r2.remove(message.author.id);
    
      embed = new Discord.MessageEmbed()
    
          .setDescription(`Você comprou o cargo 💎 **VIP** e ele expira em  \`5 Dias\`, foi descontado: **R$150,000** da sua conta.`)
          .setThumbnail("https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503")
          .setColor("#ff4747")

          embed4 = new Discord.MessageEmbed()
  
        .setDescription(`O ${message.author} comprou o cargo 💎 **VIP** e ele expira em  \`5 Dias\`, foi descontado: **R$150,000** da sua conta.`)
        .setThumbnail("https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503")
        .setColor("#ff4747")
    
      if (dinheiro < 150000) return message.reply('Para poder comprar este cargo você deve possuir **R$: 150.000** de dinheiro!')
      db.subtract(`money_${message.guild.id}_${user.id}`, 150000)
    
    let cargo = message.guild.roles.cache.get("855836960374259752");
    
    let filtro = (reaction, usuario) => reaction.emoji.name === "🔸" && usuario.id === membro.id;
    let coletor = msg.createReactionCollector(filtro, {max: 1});    
    
    message.member.roles.add(cargo.id);
    message.channel.send(embed);
    canal.send(embed4);
  })

const vipfilterl = (reaction, user) => reaction.emoji.name === '🔹' && user.id === message.author.id;
const vipLL = msg.createReactionCollector(vipfilterl);

vipLL.on('collect', r2 => { 
  r2.remove(message.author.id);
  
    embed = new Discord.MessageEmbed()
  
        .setDescription(`Você comprou o cargo 💎 **VIP** e ele expira em  \`10 Dias\`, foi descontado: **R$350,000** da sua conta.`)
        .setThumbnail("https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503")
        .setColor("#ff4747")

        embed3 = new Discord.MessageEmbed()
  
        .setDescription(`O ${message.author} comprou o cargo 💎 **VIP** e ele expira em  \`10 Dias\`, foi descontado: **R$350,000** da sua conta.`)
        .setThumbnail("https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503")
        .setColor("#ff4747")
  
    if (dinheiro < 350000) return message.reply('Para poder comprar este cargo você deve possuir **R$: 350.000** de dinheiro!')
    db.subtract(`money_${message.guild.id}_${user.id}`, 350000)
  
  let cargo = message.guild.roles.cache.get("855836960374259752");
  
  let filtro = (reaction, usuario) => reaction.emoji.name === "🔹" && usuario.id === membro.id;
  let coletor = msg.createReactionCollector(filtro, {max: 1});    
  
  message.member.roles.add(cargo.id);
  message.channel.send(embed)
  canal.send(embed3);
})


const vipfilter2 = (reaction, user) => reaction.emoji.name === '🔶' && user.id === message.author.id;
const vipLLL = msg.createReactionCollector(vipfilter2);

vipLLL.on('collect', r2 => { 
  r2.remove(message.author.id);
  
    embed = new Discord.MessageEmbed()
  
        .setDescription(`Você comprou o cargo 💎 **VIP** e ele expira em  \`20 Dias\`, foi descontado: **R$500,000** da sua conta.`)
        .setThumbnail("https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503")
        .setColor("#ff4747")

        embed2 = new Discord.MessageEmbed()
  
        .setDescription(`O ${message.author} comprou o cargo 💎 **VIP** e ele expira em  \`20 Dias\`, foi descontado: **R$500,000** da sua conta.`)
        .setThumbnail("https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503")
        .setColor("#ff4747")
  
    if (dinheiro < 500000) return message.reply('Para poder comprar este cargo você deve possuir **R$: 500.000** de dinheiro!')
    db.subtract(`money_${message.guild.id}_${user.id}`, 500000)
  
  let cargo = message.guild.roles.cache.get("855836960374259752");
  
  let filtro = (reaction, usuario) => reaction.emoji.name === "🔶" && usuario.id === membro.id;
  let coletor = msg.createReactionCollector(filtro, {max: 1});    
  
  message.member.roles.add(cargo.id);
  message.channel.send(embed);
  canal.send(embed2);
})

const vipfilter3 = (reaction, user) => reaction.emoji.name === '🔷' && user.id === message.author.id;
const vipLLLL = msg.createReactionCollector(vipfilter3);

vipLLLL.on('collect', r2 => { 
  r2.remove(message.author.id);
  
    embed = new Discord.MessageEmbed()
  
        .setDescription(`Você comprou o cargo 💎 **VIP** e ele expira em  \`1 Mês\`, foi descontado: **R$800,000** da sua conta.`)
        .setThumbnail("https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503")
        .setColor("#ff4747")


        embed1 = new Discord.MessageEmbed()
  
        .setDescription(`O ${message.author} comprou o cargo 💎 **VIP** e ele expira em  \`1 Mês\`, foi descontado: **R$800,000** da sua conta.`)
        .setThumbnail("https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503")
        .setColor("#ff4747")
  
    if (dinheiro < 800000) return message.reply('Para poder comprar este cargo você deve possuir **R$: 800.000** de dinheiro!')
    db.subtract(`money_${message.guild.id}_${user.id}`, 800000)
  
  let cargo = message.guild.roles.cache.get("855836960374259752");
  
  let filtro = (reaction, usuario) => reaction.emoji.name === "🔷" && usuario.id === membro.id;
  let coletor = msg.createReactionCollector(filtro, {max: 1});    
  
  message.member.roles.add(cargo.id);
  message.channel.send(embed);
  canal.send(embed1);
})

const vip = (reaction, user) => reaction.emoji.name === '⏩' && user.id === message.author.id;

const back = (reaction, user) => reaction.emoji.name === "↩" && user.id === message.author.id;


const vipp = msg.createReactionCollector(vip)

 const backL = msg.createReactionCollector(back)

 backL.on('collect', r => {
  const embedd = new Discord.MessageEmbed()
  .setTitle(`Cargos - Hyze \n💎 **Vips:**`)
  .setDescription(`

:small_orange_diamond: - 150k | 5 dias
:small_blue_diamond: - 350k | 10 dias
:large_orange_diamond: - 500k | 20 dias
:large_blue_diamond:  - 800k | 1 mês
  
  `)
  .addField (`**Info:**`, `Para comprar o \`cargo\` basta clicar\nno emoji de acordo com o cargo\n**Reaja ⏩ para poder ir para página 2**.`)
  .setColor('#ff4747')
  .setThumbnail('https://cdn.glitch.com/b98b4389-f89f-445c-b6db-65281520d07b%2Ficons8-online-store-64.png?v=1591924550503')

  msg.edit(embedd)
})

vipp.on('collect', r => {
  const embeddiversao = new Discord.MessageEmbed()
      .setAuthor(`${message.guild.name} - Cargos`)
      .setDescription(` 🛡️ **Cargos:**
            
      **Ghost: 150.000 Moedas** [.comprarcargo ghost]\n\
      **Suprema 250.000** [.comprarcargo suprema]\n\
        ----------/------------/--------\n\
         Em breve [Em breve]\n\
         Em breve [Em breve]\n\
         Em breve [Em breve]")

`)
      .setColor("BLUE")
      .setFooter(message.author.tag, message.author.avatarURL)
      .setTimestamp()
  msg.edit(embeddiversao)
})


});

};

exports.help = { 
    name: 'cargos',
    aliases: ['roles']
}
