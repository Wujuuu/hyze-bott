const Discord = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args) => {
    let user = client.users.cache.get(args[0]) || message.mentions.users.first() ||  message.author;

    let money = db.fetch(`money_${message.guild.id}_${user.id}`)
    if(money === null) money = 0;
  
    const embed = new Discord.MessageEmbed()
    .setColor("BLUE")
    .setThumbnail('https://media.discordapp.net/attachments/856587370362568734/856930798438842418/3587b806e68d15cbfefe1d5d8472ffd1e7252863c1ee031bebae94ee.png')
    .setTitle("💰 **|** Dinheiro na carteira")
    .setDescription(`**${user.username}**, veja as informações da sua carteira:` +
    `\n\n:dollar: Dinheiro: **R$${money}**`)
    .setFooter("Informações da sua carteira!\nUse .banco, para poder ver informações da sua conta no banco.")
    .setTimestamp();

    message.channel.send(`${user}`, embed);
}
