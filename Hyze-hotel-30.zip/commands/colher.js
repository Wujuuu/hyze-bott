const Discord = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args) => {
 
    function convertMilliseconds(ms) {
        const seconds = ~~(ms/1000)
        const minutes = ~~(seconds/60)
        
        return { minutes: minutes%60, seconds: seconds%60 }
      }
  
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    let user = message.author;
    let author = await db.fetch(`colher_${message.guild.id}_${user.id}`)

    let timeout = 606060;



    if (author !== null && timeout - (Date.now() - author) > 0) {
        let time = convertMilliseconds(timeout - (Date.now() -  author));
    

        message.channel.send(`**${member.user.tag}**, você já colheu, volta pra colher em \`${time.minutes} Minutos, ${time.seconds} segundos\`.`)
      } else {
        
    
    let hunt = [
        "🍎 `(Maça)`",
        "🍏 `(Maça Verde)`",
        "🪱 `(Maça Podre)`",
        "🐦 `(Passarinho)`",
        "🥚 `(Ovo de Passarinho)`",
        "👜 `(Sacola velha)`",
    ]

    const huntresult = Math.floor((Math.random() * hunt.length));
    let amount = Math.floor(Math.random() * 250) + 1;
        message.channel.send(`**Colhetor:** - 🧺\n**${member.user.tag}** Colheu um(a) ${hunt[huntresult]} e ganhou \`${amount}\` moedas com a colheita.`)

    db.add(`money_${message.guild.id}_${user.id}`, amount)
    db.set(`colher_${message.guild.id}_${user.id}`, Date.now())

    };
    }


module.exports.help = {
  name:"colher",
  aliases: []
}