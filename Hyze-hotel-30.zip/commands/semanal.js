const Discord = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args) => {
    
  function convertMilliseconds(ms) {
    const seconds = ~~(ms/1000)
    const minutes = ~~(seconds/60)
    const hours = ~~(minutes/60)
    const days = ~~(hours/24)
    const months = ~~(days/30)
    const years = ~~(days/365)
  
    return { years, months: months%12 , days: days%30, hours: hours%24, minutes: minutes%60, seconds: seconds%60 }
  }
  
  function convertMillisecondsEnhanced(ms) {
    const seconds = ~~(ms/1000)
    const minutes = ~~(seconds/60)
    const hours = ~~(minutes/60)
    const days = ~~(hours/24)
    const months = ~~(days/30)
    const years = ~~(days/365)
  
    return { years, months: months%12 , days: days%30, hours: hours%24, minutes: minutes%60, seconds: seconds%60 }
  }
    let user = message.author;

    let timeout = 432000000;

    let semanal = await db.fetch(`semanal_${message.guild.id}_${user.id}`);
    
    let amount = Math.floor(Math.random() * 4000) + 450;
    
    if (semanal !== null && timeout - (Date.now() - semanal) > 0) {
      let time = convertMilliseconds(timeout - (Date.now() - semanal));
  
        let timeEmbed = new Discord.MessageEmbed()
        .setColor("#008000")
        .setDescription(`:no_entry_sign: **|** Você já recebeu sua recompensa semanal!\n\nColete novamente daqui a ** ${time.days}d ${time.hours}h ${time.minutes}m ${time.seconds}s**`);
            
        message.channel.send(`${user}`, timeEmbed);

    } else {
        let moneyEmbed = new Discord.MessageEmbed()
        .setTitle(":dollar: **|** Recompensa semanal")
        .setColor("#008000")
        .setDescription(`Você coletou sua recompensa semanal!\n\n :dollar: Dinheiro Coletado: **\`R$${amount}\`**`);
        
        message.channel.send(`${user}`, moneyEmbed);
        db.add(`money_${message.guild.id}_${user.id}`, amount);
        db.set(`semanal_${message.guild.id}_${user.id}`, Date.now());
    }
}