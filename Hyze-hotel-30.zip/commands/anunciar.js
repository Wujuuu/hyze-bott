const Discord = require('discord.js');

exports.run = async (client, message, args) => {

        if(!message.member.hasPermission("ADMINISTRATOR")) return message.reply("Você não pode usar esse comando.")
        message.delete().catch()
        const content = args.join(" ");

        let splitarg = args.join(" ").split(" / ")
        let titulo = splitarg[0]
        let anuncio = splitarg[1]

        if(!titulo){
            message.reply("Use o formato ``-anunciar <titulo> / <anuncio>``")
            return
        }

        if(!anuncio){
            message.reply("Use o formato ``-anunciar <titulo> / <anuncio>``")
            return
        }

    if (!args[0]) {

 } else if (content.length > 1000) {
  return message.channel.send(`${message.author.username}, forneça uma sugestão de no máximo 1000 caracteres.`);
} else {
  var canal = message.guild.channels.cache.find(ch => ch.id === "850152028105998346");

    const msg = await canal.send(
    new Discord.MessageEmbed()
        .setColor("#FFFF00")
        .addField(`${titulo}`, `**${anuncio}**`)
        .setFooter(`Anuncio feito por ${message.author.tag}`)
        .setTimestamp()
  );
  await message.channel.send(`${message.author} a mensagem foi enviada com sucesso!`);
     }
  };