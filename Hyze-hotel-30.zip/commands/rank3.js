const Discord = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args,) => {

    const user = message.guild.member(message.mentions.users.first());

    let money = db.all().filter(data => data.ID.startsWith(`respeito_${message.guild.id}`)).sort((a, b) => b.data - a.data);
    
    let money1;
    
    if(money.length > 10){
        money1 = 10
    }else{
        money1 = money.length
    
    }
    let content = "";
    
    for(let i = 0; i < money.length; i++) {
        let user = client.users.cache.get(money[i].ID.split('_')[2])

        content += `${i+1}. ${user} - \👍 - ${money[i].data} \n`

    }

    const embed = new Discord.MessageEmbed()
    .setTitle(`👍 **|** Rank de respeito - ${message.guild.name}`)
    .setDescription(content)
    .setColor("YELLOW")
    .setFooter(`Os mas respeitado do Servidor!`)
    .setTimestamp();

    message.channel.send(`${message.author}`, embed);
}   