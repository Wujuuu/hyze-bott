const { MessageEmbed } = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args) => {
  if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send({embed: {
    description: "**:man_police_officer:  | Você precisa da permissão de `Administrador` para executar este comando**",
    color: "RANDOM"
  }})
  
  let member = message.mentions.users.first()
  if(!member) return message.channel.send({embed: {
    description: "**:man_police_officer:  | Não mencionou um usuario para remover as warns**",
    color: "RANDOM"
  }})
  

  let warns = await db.get(`warnsCount_${message.guild.id}-${member.id}`)
  
  if(!args[1]) return message.channel.send({embed: {
    description: "**Dê uma quantia de warns a ser removida**",
    color: "RANDOM"
  }})
  
  if(message.content.includes(" -")) return message.channel.send({embed: {
    description: "**Você não pode retirar uma quantia negativa de warns**",
    color: "RANDOM"
  }})
  
  if(member.id === message.author.id) return message.channel.send({embed: {
    description: "**Não podes retirar warns de você mesmo!**",
    color: "RANDOM" 
  }})
  
  
  if(warns < args[1]) return message.channel.send({embed: {
    description: "**Não podes retirar warns que o user não possui**",
    color: "RANDOM"
  }})
  
  const rwarns = new MessageEmbed()
  .setTitle("⛔ Warn removido")
  .setColor("RANDOM")
  .setFooter(`Warn removido com sucesso`, message.author.displayAvatarURL())
  .addField("Removido de", `\`${member.tag}\``)
  .addField("Removido por", `\`${message.author.tag}\``)
  .setThumbnail('https://media.discordapp.net/attachments/805073314112077854/818699365689327626/1692_Sirenevermelha.gif?width=80&height=80')
  message.channel.send(rwarns)
  
  db.subtract(`warnsCount_${message.guild.id}-${member.id}`, args[1])
  
 let channel = message.guild.channels.cache.get(db.get(`cMod_${message.guild.id}`))
if(!channel) {
  return
} else {

const arns = new MessageEmbed()
  .setTitle("⛔ Warn removido")
  .setColor("RANDOM")
  .setFooter(`Warn removido com sucesso`, message.author.displayAvatarURL())
  .addField("Removido de", `\`${member.tag}\``)
  .addField("Removido por", `\`${message.author.tag}\``)
  .setThumbnail('https://media.discordapp.net/attachments/805073314112077854/818699365689327626/1692_Sirenevermelha.gif?width=80&height=80')
  channel.send(arns)

}


}