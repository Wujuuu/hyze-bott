const { MessageEmbed } = require('discord.js');
const db = require('quick.db');

module.exports = {
    name: 'inventory',
    description: "View Your Inventory",
    aliases: ['inven', 'int', 'inv'],
    usage: "[prefix]inventory",
    run: async(client, message, args) => {

        let items = db.fetch(`items_${message.guild.id}_${message.author.id}`)
        if(items === null) items = "Você ainda nao comprou nada, digite .loja";

        const Embed = new MessageEmbed()
        .addField('Inventario', items)
        .setColor("YELLOW")

        message.channel.send(Embed)
    }
}