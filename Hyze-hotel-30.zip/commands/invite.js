const discord = require('discord.js')

module.exports = {
    name: "invite",
    category: "discord",
    run: async (client, message, args) => { 

        const regedit = new discord.MessageEmbed()
            .setColor(`#ffff00`)
            .setTitle(`Me convide para o seu servidor!`)
            .setDescription(`Meu link de convite: (https://discord.com/oauth2/authorize?client_id=845024786358075422&scope=bot&permissions=4220943)`)
        await message.channel.send(regedit)
    }
}
