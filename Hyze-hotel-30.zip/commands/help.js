const Discord = require('discord.js');
const c = require('../config.json')

module.exports.run = async (client, message, args) => {
    message.delete()

    const erros = new Discord.MessageEmbed()
        .setAuthor("Hyze ajuda - Erro", client.user.avatarURL)
        .setDescription(`${message.author}, não consigo enviar mensagem para você, ative suas mensagens diretas!`)
        .setTimestamp()
        .setThumbnail(client.user.avatarURL)
        .setFooter(message.author.tag, message.author.avatarURL)
        .setColor('YELLOW')

    const yes = new Discord.MessageEmbed()
        .setAuthor(`${message.guild.name} - Ajuda`)
        .setDescription(` ${message.author}, enviei meus comandos em seu privado!`)
        .setTimestamp()
        .setColor("YELLOW")
        .setFooter(message.author.tag, message.author.avatarURL)
    message.channel.send(yes).then(msg => msg.delete({ timeout: 10000 }))

    const embed = new Discord.MessageEmbed()
        .setAuthor(`${message.guild.name} - Ajuda`)
        .setDescription(`Para saber meus comandos, reaja ao emoji de cada categoria.`)
        .addField(`Reaja:`, '⭐ **Informações**\n😂 **Diversão**\n🔧 **Staff**\n💰 **Economia**\n💠 **Vip**')
        .setFooter(message.author.tag, message.author.avatarURL)
        .setTimestamp()
        .setColor('YELLOW')
    message.author.send(embed).catch(err => message.channel.send(erros)).then(async msg => {
        await msg.react('⭐')
        await msg.react('😂')
        await msg.react('🔧')
        await msg.react('💰')
        await msg.react('💠')
        await msg.react("↩")


        const informacao = (reaction, user) => reaction.emoji.name === '⭐' && user.id === message.author.id;
        const diversao = (reaction, user) => reaction.emoji.name === '😂' && user.id === message.author.id;
        const staff = (reaction, user) => reaction.emoji.name === '🔧' && user.id === message.author.id;
        const economia = (reaction, user) => reaction.emoji.name === '💰' && user.id === message.author.id;
        const vip = (reaction, user) => reaction.emoji.name === '💠' && user.id === message.author.id;

        const back = (reaction, user) => reaction.emoji.name === "↩" && user.id === message.author.id;

        const informacaoL = msg.createReactionCollector(informacao)
        const diversaoL = msg.createReactionCollector(diversao)
        const staffL = msg.createReactionCollector(staff)
        const economia1 = msg.createReactionCollector(economia)
        const vipL = msg.createReactionCollector(vip)

        const backL = msg.createReactionCollector(back)


        backL.on('collect', r => {
            const embedd = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`Para saber meus comandos, reaja ao emoji de cada categoria.`)
                .addField(`⭐ **Informações**`, '•')
                .addField(`😂 **Diversão**`, '•')
                .addField(`🔧 **Staff**`, '•')
                .addField(`💠 **Vip**`, '•')
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
                .setColor("YELLOW")
            msg.edit(embedd)
        })

        informacaoL.on('collect', r => {

            const embedinformacao = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`⭐ **Informações**

                .help - Exibe o menu de ajuda.
                .serverinfo - Mostra informação do servidor.
                .botinfo - Mostra informações sobre mim.
                .invites - Mostra o rank de convites.
                .lembrete \`<tempo>\` \`<lembrete>\` - Te lembra de algo importante.
                .ping - Mostra o delay bot-servidor.
                .userinfo - Mostrar informações do usuário.
                .link - Manda o link do hotel.
                .respeitos - Mostra seus respeitos.
                .avatar - Pega a foto de perfil do usuário selecionado.
                .servericon - Manda a foto do servidor.
                **.cargos - Mostra a loja de cargos.**
                .level - Mostra seu level.
                .levelrank - Mostra o level de todos.
                      `)
                .setColor("YELLOW")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embedinformacao)
        })

        diversaoL.on('collect', r => {
            const embeddiversao = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`😂 **Ultilidade**

                .coinflip - Joga moeda para cima.
                .covid \`<país>\` - Total de Covid-19.
                .enquete - bot te lembra de algo.
                .bug - reporta um bug do servidor ou do hotel aos staff.
                .ticket - abre um chat de ajuda com os staff.
                .pesquisar - fazer uma pesquisa no google.
                .velha - Jogo da Velha.
                .snake - Jogo da Cobra.
                .ship - lhe mostra a porcentagem entre você e a pessoa selecionada.
                .poke - cutuca a pessoa selecionada.
                .smite - joga um raio na pessoa mencionada.
                  `)
                .setColor("YELLOW")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embeddiversao)
        })

        staffL.on('collect', r => {
            const embeddiversao = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`🔧 **Staff**
                        
                .clear - limpa o chat.
                .say - faz o bot repetir tudo que você fala.
                .saye -  faz o bot repetir tudo que você fala em embed.
                .mute - a pessoa fica mutada até ser desmutada por um adm.
                .unmute - Desmuta a pessoa.
                .tempmute - a pessoa é mutada, e quando der o tempo selecionado ela desmuta automaticamente.
                .kick - Expulsa uma pessoa do servidor.
                .ban - bani alguém do servidor.
                .anunciar - para fazer um anuncio em embed.
                .addcargo - adiciona um cargo ao usuário.
                .enquete - cria uma votação como emoji aos user.
                .warn - alerta o usuário mencionado.
                .unwarn - remove um alerta.
                .warnlist - mostra quantos warn o usuário mencionado tem.
                .addcargo - adiciona cargo no usuário mencionado.
                .removecargo - remove cargo do usuário mencionado.
                .addnick - muda o nick.
                .setmoney - altera o dinheiro do user.
                .sorteio - faz um sorteio.
                .dm - faz o bot mandar mensagem no privado de alguém.
                .addemoji - o bot adiciona emoji no grupo.
 
        `)
                .setColor("YELLOW")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embeddiversao)
        })

        economia1.on('collect', r => {
            const embeddiversao = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`💰 **Economia**
          
                .roubar - você rouba dinheiro de um usuário.
                .carteira - Mostra seu dinheiro.
                .banco - Mostra seu dinheiro do banco.
                .rank - Mostra o rank de dinheiro.
                .rank2 - Mostra o rank do banco.
                .inventario - Mostra os items que você comprou.
                .loja - Mostra os items da loja
                .buy - Compra um item da loja.
                .daily - Resgata seu dinheio diário.
                .semanal - Resgata seu dinheiro semanal.
                .pay - paga uma pessoa.
                .dep - deposita o dinheiro no banco.
                .saque - saca o dinheiro do banco.
                .aposta - você faz apostas contra o bot.
                .roleta - Você aposta na roleta.
                .emprego - Você escolhe o serviço que vai trabalhar.
                .trabalhar - Você trabalha no emprego escolhido.
                .demissão - Você se demite do servição atual.
                .caçar - Você caça e ganha dinheiro.
                .pescar - Você pesca e ganha dinheiro.
                .colher - Você colhe e ganha dinheiro.
                .lixo - Você colheta o lixo e ganha dinheiro.
                .jornal - Você entrega o jornal e ganha dinheiro.
                .bixo - você faz apostas contra o bot. 
                .dungeon - Ganha xp e dinheiro.
                .apostadima - Você faz um aposta contra o bot.
                .richa - você tira x1 contra o bot, briga de animais.
                .prisão - mostra os users preso na richa.
        `)
                .setColor("YELLOW")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embeddiversao)
        })
           vipL.on('collect', r => {
            const embeddiversao = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name} - Ajuda`)
                .setDescription(`💠 **VIP/Economia VIP**

                .bebidas - Você vende bebidas e ganha dinheiro.
                .leilao - Você vende um animal no leilão e ganha dinheiro.
                .policial - Você prende alguém e ganha dinheiro.
                .roupa - Você vende roupas e ganha dinheiro.
                .gf - Você faz gf com alguém e ganha dinheiro.
                .roletav - Faz apostas na roleta.
                .dailyvip - Resgata o dinheiro diário do vip.
                .cripta - Ganha xp e dinheiro.
                .mensal - recebe dinheiro de 1 mês todo.


                **😂 Diversão Vip**
                
                .slap - bate em alguém.
                .smug - mostra que você é presunçoso.
                .tickle - Cutuca alguém.
                .cuddle - abraça um usuário mencionado.
                .idiota - chama alguém de idiota.
                .pat - dá um tapinha em um usuário mencionado.
                .feed - alimenta um usuário mencionado.
                .kiss - beija um usuário mencionado.


               
 
        `)
                .setColor("BLUE")
                .setFooter(message.author.tag, message.author.avatarURL)
                .setTimestamp()
            msg.edit(embeddiversao)
        })



    })
}


exports.help = {
    name: "ajuda",
    aliases: ['help']
}