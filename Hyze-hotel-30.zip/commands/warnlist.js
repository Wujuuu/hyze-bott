const Discord = require("discord.js");
const db = require("quick.db");

module.exports = {
name: "warns",
aliases: ["userwarn"],
run: async (client, message, args) => {

let user = message.mentions.members.first() || message.author;
if(!user) {

return message.channel.send("Mencione um user")
}

let warns = await db.get(`warnsCount_${message.guild.id}-${user.id}`) || 0;

const embed = new Discord.MessageEmbed()

.setTitle(':man_police_officer: | Warns')
.setDescription(`**${user} Tem ${warns} Warns**`)
.setColor('YELLOW')

message.channel.send(embed);
}
}