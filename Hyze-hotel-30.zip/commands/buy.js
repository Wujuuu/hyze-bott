const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async (client, message, args) => {

    let canal = client.channels.cache.get("855544094596399154")//id do canal
    let autor = message.author;
    let server = message.guild;
    let bug = args.join(" ")

    if(!message.content.startsWith('.'))return;  

    let user = message.author;

    let items = await db.fetch(`items_${message.guild.id}_${message.author.id}`, {items: []})

    let author = db.fetch(`money_${message.guild.id}_${user.id}`)

    let Embed = new Discord.MessageEmbed()
    .setColor("#FFFFFF")
    .setDescription(`:x: você precisa de 36000 moedas para comprar 150 diamantes.`);

    if (args[0] == 'diamantes') {
        if (author < 36000) return message.channel.send(Embed)
        
        db.fetch(`diamantes_${message.guild.id}_${user.id}`);
        db.set(`diamantes_${message.guild.id}_${user.id}`, true)

        let Embed2 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:white_check_mark: Você comprou 150 **Diamantes por 36000** moedas.`);

        db.subtract(`money_${message.guild.id}_${user.id}`, 36000)
        db.push(`items_${message.guild.id}_${message.author.id}`, "150 diamantes")
        message.channel.send(Embed2)
    } else if(args[0] == 'sofá') {
        let Embed2 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:x: você precisa de 600 moedas para comprar Sofá custom.`);

        if (author < 600) return message.channel.send(Embed2)
       
        db.fetch(`sofá_${message.guild.id}_${user.id}`)
        db.add(`sofá_${message.guild.id}_${user.id}`, 1)

        let Embed3 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:white_check_mark: Você comprou **1 sofá custom** por 600 moedas.`);

        db.subtract(`money_${message.guild.id}_${user.id}`, 600)
        db.push(`items_${message.guild.id}_${message.author.id}`, "sofá custom")
        message.channel.send(Embed3)
    } else if(args[0] == 'serpa') {
        let Embed2 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:x: você precisa de 800 moedas para comprar serpa custom.`);

        if (author < 800) return message.channel.send(Embed2)
       
        db.fetch(`serpa_${message.guild.id}_${user.id}`)
        db.add(`serpa_${message.guild.id}_${user.id}`, 1)

        let Embed3 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:white_check_mark: Você comprou **1 serpa custom** por 600 moedas.`);

        db.subtract(`money_${message.guild.id}_${user.id}`, 800)
        db.push(`items_${message.guild.id}_${message.author.id}`, "serpa custom")
        message.channel.send(Embed3)
    } else if(args[0] == 'emblema') {
        let Embed2 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:x: você precisa de 1200 moedas para comprar emblema`);

        if (author < 1200) return message.channel.send(Embed2)
       
        db.fetch(`emblema_${message.guild.id}_${user.id}`)
        db.add(`emblema_${message.guild.id}_${user.id}`, 1)
        
        let Embed3 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:white_check_mark: Você comprou **1 emblema ** por 1200 moedas.`);

        db.subtract(`money_${message.guild.id}_${user.id}`, 1200)
        db.push(`items_${message.guild.id}_${message.author.id}`, "emblema")
        message.channel.send(Embed3)
    } else {
        let embed3 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(':x: selecione 1 item da loja para ser comprado.')
        message.channel.send(embed3)
    }

    
    const log1 = new Discord.MessageEmbed()
    .setTitle(`Loja Log`)
    .setColor("#ffff00")
    .setThumbnail(`${message.author.displayAvatarURL({dynamic: true})}`)
    .setDescription(`Novo item adquirido.`)
    .addField("Autor:", message.author)
    .addField("Item:", `${args[0]}`)
     canal.send(log1).catch(console.error);

}

  
  module.exports.help = {
    name:"buy",
    aliases: [""]
  }