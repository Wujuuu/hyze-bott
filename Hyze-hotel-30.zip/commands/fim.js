module.exports = {
    config: {
        name: "end",
        description: "Ends a giveaway.",
        usage: "",
        category: "Giveaways",
        accessableby: "Admins",
        aliases: [], // To add custom aliases just type ["alias1", "alias2"].
    },
    run: async (client, message, args) => {

        if (!message.member.hasPermission('MANAGE_MESSAGES') && !message.member.roles.cache.some((r) => r.name === "Giveaways")) {
            return message.channel.send(':boom: Você não tem permissão de \`MANAGE_MESSAGES\` para finalizar um sorteio.');
        }

        if (!args[0]) {
            return message.channel.send(':boom: Opss não encontrei essa mensagem, use ,end \`<id da mensagem>!\`');
        }

        let giveaway =
            client.giveawaysManager.giveaways.find((g) => g.prize === args.join(' ')) ||
            client.giveawaysManager.giveaways.find((g) => g.messageID === args[0]);

        if (!giveaway) {
            return message.channel.send(':boom: não consigo encontrar um sorteio em `' + args.join(' ') + '`.');
        }
        client.giveawaysManager.edit(giveaway.messageID, {
            setEndTimestamp: Date.now()
        })
            .then(() => {
                message.channel.send('O sorteio terminará em  ' + (client.giveawaysManager.options.updateCountdownEvery / 1000) + ' segundos...');
            })
            .catch((e) => {
                if (e.startsWith(`O Sorteio do id mencionado ${giveaway.messageID} já terminou.`)) {

                    message.channel.send('Este sorteio já terminou!');

                } else {
                    console.error(e);
                    message.channel.send('Ops ocorreu um erro...');
                }
            });
    },
}