const db = require("quick.db");

module.exports = {
    name: "setxp notificação",
    author: "chokito0",

    run: async(client, message, args) => {

        let hyze_author = message.author;
        let hyzee_error_perm = "Você não possui permissão para utilizar este comando.";
        let hyzeee_msg_error = "Você deve escrever com \`.setxp #canal\`.";
        let hyze1_confirmado = "Canal setado";

        if(!message.member.hasPermission("MANAGE_GUILD")) return message.channel.send(`:x: | ${hyze_author} ${hyzee_error_perm}`)

        let hyyyze = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);

        if(!hyyyze) return message.channel.send(`:x: | ${hyze_author} ${hyzeee_msg_error}`);

        db.set(`hyyyze_xp_${message.guild.id}`, hyyyze.id);

        let hyyze_xp = db.get(`hyyyze_xp_${message.guild.id}`, hyyyze.id);

        message.channel.send(`✅ | ${hyze_author} ${hyze1_confirmado} para <#${hyyze_xp}> com sucesso.`)
    }
}