const Levels = require("discord-xp");
const Discord = require('discord.js');

exports.run = async (client, message, args) => {

    const rawLeaderboard = await Levels.fetchLeaderboard(message.guild.id, 10); // We grab top 10 users with most xp in the current server.

    if (rawLeaderboard.length < 1) return reply("Ninguém está na tabela de classificação ainda.");
    
    const leaderboard = await Levels.computeLeaderboard(client, rawLeaderboard, true); // We process the leaderboard.
    
    const lb = leaderboard.map(e => `${e.position} |  ${e.username}#${e.discriminator}\nLevel: ${e.level}\nXP: ${e.xp.toLocaleString()}`); // We map the outputs.
    
const leaderboardEmbed = new Discord.MessageEmbed()
    .setColor('BLUE')
    .setAuthor('Rank de leveis')
    .setDescription(`**${lb.join('\n\n')}**`)
    .setTimestamp()
    .setFooter(client.user.username, client.user.displayAvatarURL());

    
    message.channel.send(leaderboardEmbed);


}