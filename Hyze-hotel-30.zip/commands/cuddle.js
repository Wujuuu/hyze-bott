const client = require('nekos.life');
const Discord = require('discord.js')
const neko = new client();

module.exports = {
  name: "cuddle",
  category: "expressões",
  description: "abraça um usuário mencionado",
  usage: "[command] + [user]",
  run: async (client, message, args) => {

      if (!message.member.permissions.has("SEND_TTS_MESSAGES"))
      return message.reply(
      "Apenas usuários vips podem usar esse comando."
      );
  
  //command

        const user = message.mentions.users.first();
        if(!user)
        return message.reply('Mencione alguém para abraçar.');

        async function work() {
        let owo = (await neko.sfw.cuddle());

        const cuddleembed = new Discord.MessageEmbed()
        .setTitle(user.username + " Você acabou de receber um abraço! ")
        .setDescription((user.toString() + " recebeu um abraço de " + message.author.toString()))
        .setImage(owo.url)
        .setColor(`#000000`)
        .setURL(owo.url);
        message.channel.send(cuddleembed);

}

      work();
}
                };