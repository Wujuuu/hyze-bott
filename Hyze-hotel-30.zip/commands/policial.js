const db = require("quick.db") 
const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {

    if (!message.member.permissions.has("SEND_TTS_MESSAGES"))
    return message.reply(
    "Apenas usuários vips podem usar esse comando."
    );


    function convertMilliseconds(ms) {
        const seconds = ~~(ms/1000)
        const minutes = ~~(seconds/60)
        
        return { minutes: minutes%60, seconds: seconds%60 }
      }
    
 const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
 let user = message.author;
 let author = await db.fetch(`policial_${message.guild.id}_${user.id}`)

 let timeout = 606060;
    
 if (author !== null && timeout - (Date.now() - author) > 9000) {
    let time = convertMilliseconds(timeout - (Date.now() -  author));

        message.channel.send(`**${member.user.tag}**, você já prendeu recentemente, tente novamente em \`${time.minutes} minutos, ${time.seconds} segundos\`.`)
      } else {

    let fish = [
    "🕵️ `(Bandido)`",
    "🙍‍♂️ `(Traficante)`",
    "🙎‍♂️ `(Assassino)`",
    ]
    let fishresult = Math.floor((Math.random() * fish.length));
    let amount = Math.floor(Math.random() * 550) + 320;
        if (!args[0]) {
        message.channel.send(`**Policial:** - 👮‍♂️\n**${member.user.tag}** prendeu ${fish[fishresult]} e ganhou \`${amount}\` moedas com a prisão.`)
    db.add(`money_${message.guild.id}_${user.id}`, amount)
    db.set(`policial_${message.guild.id}_${user.id}`, Date.now())
    }
   }
}
module.exports.help = {
    name:"fish",
    aliases: []
}