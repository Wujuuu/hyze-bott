const Discord = require ('discord.js')

exports.run = async (client, message, args, prefix) => {

let user = message.mentions.users.first()
if(!user) return message.reply("por favor marque um usuario valido para executar o comando")

let nickname = args.slice(1).join("")
if(!nickname) return message.reply("por favo diga um nick valido ")

let member = message.guild.members.cache.get(user.id);
await member.setNickname(nickname);

message.channel.send(`**prontinho ${message.author} nickname setado **`)
}