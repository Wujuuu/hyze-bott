const client = require('nekos.life');
const Discord = require('discord.js')
const neko = new client();


module.exports = {
  name: "kiss",
  category: "expressões",
  description: "beija um usuário mencionado",
  usage: "[command] + [user]",
  run: async (client, message, args) => {

      if (!message.member.permissions.has("SEND_TTS_MESSAGES"))
      return message.reply(
      "Apenas usuários vips podem usar esse comando."
      );
  
  //command

        const user = message.mentions.users.first();
        if(!user)
        return message.reply('Mencione alguém para beijar');

        async function work() {
        let owo = (await neko.sfw.kiss());

        const kissembed = new Discord.MessageEmbed()
        .setTitle(user.username + " Você foi beijado! ")
        .setDescription((user.toString() + " foi beijado por " + message.author.toString()))
        .setImage(owo.url)
        .setColor(`#000000`)
        .setURL(owo.url);
        message.channel.send(kissembed);

}

      work();
}
                };