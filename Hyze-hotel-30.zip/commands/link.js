const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {
    let clientping = new Date() - message.createdAt;

    message.channel.send(`${message.author}`)
    let embed = new Discord.MessageEmbed()
      .setTitle(' 💻 Se liga no nosso hotel 💻')
      .setDescription('🔗 https://hyze.online/')
      .setFooter('Criado pela a equipe Hyze.')
      .setColor('#fff200');

        message.channel.send(embed)
}

module.exports.help = {
    name: "link do hotel"
}