const Discord = require("discord.js");
const Levels = require("discord-xp");
const db = require("quick.db");

exports.run = async (client, message, args) => {
function convertMilliseconds(ms) {
        const seconds = ~~(ms/1000)
        const minutes = ~~(seconds/60)
        const hours = ~~(minutes/60)
        const days = ~~(hours/24)
      
        return { days, hours: hours%24, minutes: minutes%60, seconds: seconds%60 }
      }
      
    

    let autor = message.author;
    let user = message.author;


    let timeout = 1980000;

    let daily = await db.fetch(`dungeons_${message.guild.id}_${autor.id}`);

    if (daily !== null && timeout - (Date.now() - daily) > 0) {


 let time = convertMilliseconds(timeout - (Date.now() - daily));
      
        let timeEmbed = new Discord.MessageEmbed()
        .setColor("#4B0082")
        .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/857388214217736212/dungeondoor_by_exonto_dcfjk88-fullview.png')
        .setDescription(` Você tentou passar pela a dungeon a pouco tempo!\n\nTente novamente daqui a **${time.hours}h ${time.minutes}m ${time.seconds}s**`);
        
        message.channel.send(`${autor}`, timeEmbed);
    } else {
        
        let sorte = Math.floor(Math.random() * 4) + 1;
        
        if(sorte == 2) {
            
            let amount = Math.floor(Math.random() * 150) + 8;
            
            let moneyEmbed = new Discord.MessageEmbed()
            .setTitle("Sua Dungeon falhou!")
            .setColor("RED")
            .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/857388214217736212/dungeondoor_by_exonto_dcfjk88-fullview.png')
            .setDescription(`Você tentou passar pela a Dungeon e não se saiu muito bem!\nE você perdeu um total de **R$${amount}**!`)
            .setFooter(`estatistica da dungeon`);

            message.channel.send(`${autor}`, moneyEmbed);
            db.subtract(`money_${message.guild.id}_${autor.id}`, amount);
            db.set(`dungeons_${message.guild.id}_${autor.id}`, Date.now());
        }else{

            let historia = new Discord.MessageEmbed()
            .setTitle("Dungeon")
            .setColor("#7FFFD4")
            .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/857388214217736212/dungeondoor_by_exonto_dcfjk88-fullview.png')
            .setDescription("Um ex-harpista que se tornou um ladrão foge da prisão com sua parceira, uma bárbara, e se reúne com um mago sem talento e um druida novato ao time. Com o objetivo de de roubar o golpista traiçoeiro que roubou todo o saque da última missão, o que os colocou atrás das grades, e usou isso para se estabelecer como Lorde de Neverwinter. Acontece que o traidor se aliou com um poderoso Mago Vermelho que tem algo ainda mais sinistro em desenvolvimento.")
            .setFooter(`reaja com 🧺, para poder ver seu loot.`);


            message.channel.send(historia).catch(err => message.channel.send(erros)).then(async msg => {
                await msg.react('🧺')

           const loot = (reaction, user) => reaction.emoji.name === '🧺' && user.id === message.author.id;

           const LootL = msg.createReactionCollector(loot)
        
            
            const randomAmountOfXp = Math.floor(Math.random() * 11) + 9;
            

            Levels.appendXp(message.author.id, message.guild.id, randomAmountOfXp);
    
               const user = await Levels.fetch(message.author.id, message.guild.id);

            let amount = Math.floor(Math.random() * 350) + 150;


            
            LootL.on('collect', r => {

          const looot = new Discord.MessageEmbed()
             .setTitle("Loot da dungeon:")
             .setColor("PINK")
             .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/857388214217736212/dungeondoor_by_exonto_dcfjk88-fullview.png')
             .setDescription(`**Usuário:**\n${autor}\n\n💰 **Dinheiro ganho:**\n**${amount}.**\n\n<:unnamed:859596024334778398> **Xp ganho:** \n${randomAmountOfXp} experiência.\n\n<:levelup:859596052611989524> **level:** \n      ${user.level}.`)
             .setFooter(`estatistica da dungeon`);
            
             msg.edit(looot)
            db.add(`money_${message.guild.id}_${autor.id}`, amount);
            db.set(`dungeons_${message.guild.id}_${autor.id}`, Date.now());


        })
    })
}
}
};
