const client = require('nekos.life');
const Discord = require('discord.js')
const neko = new client();
module.exports = {
  name: "smug",
  category: "emoções",
  description: "mostra que você é presunçoso",
  usage: "[command]",
  run: async (client, message, args) => {
	  
	   if (!message.member.permissions.has("SEND_TTS_MESSAGES"))
    return message.reply(
    "Apenas usuários vips podem usar esse comando."
    );

  //command

        async function work() {
        let owo = (await neko.sfw.smug());

        const smug = new Discord.MessageEmbed()
        .setTitle("Alguém é presunçoso")
        .setDescription(( message.author.toString() + "demostra como é presunçoso "))
        .setImage(owo.url)
        .setColor(`YELLOW`)
        .setURL(owo.url);
        message.channel.send(smug);

}

      work();
}
                };