const Discord = require('discord.js');
exports.run = async (client, message, args) => {
    if (!args[0]) return message.channel.send(`${message.author} você precisa Mencionar alguem!`);

 const dh = [
'0% ambos concorda só amizade bah;',
'10% muito dificil',
'20% difícil',
'30% talvez role alguma coisa',
'40% as chances são grandes',
'quase certeza que vai rolar!',
'60% pode ser amor verdadeiro',
'70% eles parecem almas gêmeas',
'80% amor verdadeiro',
'90% eles tem que ficar juntos',
'100% casal pfto:3',
 ]
  var dhship = dh[Math.floor(Math.random() * dh.length)];
  let dhuser = message.mentions.users.first() || client.users.cache.get(args[0]);
  
 const dhzin = new Discord.MessageEmbed()
 .setTitle('🤍***__ship__***🤍')
 .setColor('YELLOW')
 .setTimestamp()
 .setDescription(`ship entre ${message.author} e ${dhuser}`)
   .addFields(
                {
                    name: "***resultados***",
                    value: dhship
                },
                    )
 message.channel.send(dhzin)
}