const Discord = require("discord.js");
const  { MessageEmbed } = require("discord.js")
const manage_roles = require('../modules/manage_roles');
const db = require("quick.db");

module.exports.run = async (client, message, args) => {
message.delete();

let canal = client.channels.cache.get("852001958357237781")//id do canal
let autor = message.author;
let server = message.guild;
let bot = client.user;
let bug = args.join(" ")

  if(!message.member.hasPermission(["MANAGE_ROLES", "ADMINISTRATOR"])) return message.channel.send({embed: {
    description: "**:x: Você precisa da permissão de `Gerenciar Cargos` para executar este comano",
    color: "#ff0000"
  }})
  
  let member = message.mentions.users.first() 
  if(!member) return message.channel.send({embed: {
    description: "**:x: Você deve mencionar um usuário a ser Avisado**",
    color: "#ff0000"
  }})
  
  if(member.id === message.author.id) return message.channel.send({embed: {
    description: "**:x: Não podes dar warn em você mesmo**",
    color: "#ff0000"
  }})
  const user = message.guild.member(message.mentions.users.first());
    if (!user) return message.channel.send("Usuário inválido!");
//pv

 let motivo = args.slice(1).join(" ")
  if(!motivo) return message.channel.send({embed: {
    description: "**:x: Você precisa setar um motivo para avisar o usuario**",
    color: "#ff0000"
  }})

  message.mentions.members.map((member) => { 
const pv = new Discord.MessageEmbed()
  .setTitle(":no_entry: Você foi alertado!")
   .addField("Avisado", `\`você foi alertado no servidor ${message.guild.name}, da proxima vez leia as regras!\``)
  .addField("Motivo", `\`${motivo}\``)
  .setColor("#ffff00")
        user.send(pv);
        

    });


const embed1 = new MessageEmbed()
    .setTitle(`Hyze Log`)
    .setColor("#ffff00")
    .setDescription(`O usuário ${member} foi alertado!`)
    .addField("Motivo", `\`${motivo}\``)
    .addField("Autor:", message.author)
    .setAuthor(":", member.displayAvatarURL())
    .setTimestamp();
    canal.send(embed1);

  
  const aviso = new Discord.MessageEmbed()
  .setTitle(":no_entry: Membro Avisado!")
   .addField("Avisado", `\`${member.tag}\``)
  .addField("Avisado por", `\`${message.author.tag}\``)
  .addField("Motivo", `\`${motivo}\``)
  .setFooter(`Warn Efetuado`, message.author.displayAvatarURL())
  .setColor("#ffff00")
  message.channel.send(aviso).then(msg => msg.delete({timeout:2500}));
  db.add(`warnsCount_${message.guild.id}-${member.id}`, 1)
  
  let channel = await message.guild.channels.cache.get(db.get(`cMod_${message.guild.id}`))
  if(!channel) {
    return
  } else {
  const embed2 = new Discord.MessageEmbed()
  .setAuthor("Warn Member", member.displayAvatarURL())
  .addField("Avisado", `\`${member.tag}\``)
  .addField("Avisado por", `\`${message.author.tag}\``)
  .addField("Motivo", `\`${motivo}\``)
  .setColor("#ffff00")
  .setTimestamp()
  channel.send(embed2)
  
 }
}