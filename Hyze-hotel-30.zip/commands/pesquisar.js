const Discord = require("discord.js");

module.exports.run = async (client, message, args) => {


let link = args.join(' ')    
 
 let noArgs = new Discord.MessageEmbed()
 .setColor('YELLOW') //escolha uma cor 
 .setDescription(`você deve colocar algo para pesquisar!`) 

if(!args[0]) return message.channel.send(noArgs);

 const embed = new Discord.MessageEmbed()
 .setTitle (`Sua pesquisa no google`)
 .setColor('YELLOW') //escolha uma cor 
 .setDescription (`[Clique Aqui] (https://www.google.com/search?q=${link})`)
 .setImage ("https://i.pinimg.com/originals/3d/33/f1/3d33f1635eb1a598c9ffb68ae23d3b81.gif")
message.channel.send(embed)

};