const Discord = require("discord.js");
const db = require('quick.db');
const Levels = require("discord-xp");
module.exports.run = async (client, message, membro, args) => {

    let user = message.author;
    let autor = message.author;


    function convertMilliseconds(ms) {
        const seconds = ~~(ms/1000)
        const minutes = ~~(seconds/60)
        const hours = ~~(minutes/60)
        const days = ~~(hours/24)
      
        return { days, hours: hours%24, minutes: minutes%60, seconds: seconds%60 }
      }



      let timeout = 1980000;

      let daily = await db.fetch(`prisao_${message.guild.id}_${autor.id}`);
      if (daily !== null && timeout - (Date.now() - daily) > 0) {
  
   let time = convertMilliseconds(timeout - (Date.now() - daily));



   let timeEmbed = new Discord.MessageEmbed()
   .setColor("#ADFF2F")
   .setThumbnail('https://images-ext-2.discordapp.net/external/8zddOdw1zVr_dmm6WleKLsOPcpu8H10wjZLfKG9bE-M/https/images-ext-2.discordapp.net/external/HnKfZj2LRMudBZjyMw5oVXz58suPFYPiWTZOHFV8Cjs/https/acegif.com/wp-content/gifs/police-car-94.gif')
   .setDescription(`Você foi pego pela a policia tentando apostar na richa.\nRichas são ilegais cuidado da proxima vez!\n\n**TEMPO:**\nPreso por: \`${time.hours}h ${time.minutes}m ${time.seconds}s\``);
   
   message.channel.send(`${autor}`, timeEmbed);

    } else {
     


let embed = new Discord.MessageEmbed()

  .setTitle(`**RICHAS**`)
  .setDescription(`Você está preste a entrar na richa de animais.\nRichas são ilegais, ao apostar nelas, você aceita o risco de ser preso!`)
  .addField (`**Info:**`, `Para entrar na \`richa\` basta clicar no emoji: \n**▶️ para poder ir apostar**.`)
  .setColor('#EE82EE')
  .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/859955286609887242/Pngtreegangster_dog_vector_4768385.png?width=559&height=559')
message.channel.send({embed}).then(msg=>{
      msg.react('▶️')
      msg.delete({timeout: 8000})

      message.delete({ timeout: 1000 });
  
  const vipfilter = (reaction, user) => reaction.emoji.name === '▶️' && user.id === message.author.id;
  const vipL = msg.createReactionCollector(vipfilter);
  
  vipL.on('collect', r2 => { 
    r2.remove(message.author.id);
    
      embedd = new Discord.MessageEmbed()
    
          .setDescription(`Escolha em qual animal você irá apostar\n\n**Info:**\n Basta reagir aos emote abaixo.`)
          .setThumbnail("https://media.discordapp.net/attachments/857060559132688414/859955286609887242/Pngtreegangster_dog_vector_4768385.png?width=559&height=559")
          .setColor("#ff4747")
    
     const filter = (reaction, user) => {
    return ['🐶', '🐺', '🦁'].includes(reaction.emoji.name) && user.id === message.author.id;
        }

    let filtro = (reaction, usuario) => reaction.emoji.name === "▶️" && usuario.id === membro.id;
    let coletor = msg.createReactionCollector(filtro, {max: 1});   
    message.channel.send(embedd).then(msg=>{
     msg.react("🐶")
     msg.react("🐺")
     msg.react("🦁")
    
  
     let sorte = Math.floor(Math.random() * 4) + 1;
     msg.delete({ timeout: 16000, embedd })

   
     if(sorte == 2) {
         
         let amount = Math.floor(Math.random() * 250) + 8;
         
         let moneyEmbed = new Discord.MessageEmbed()
         .setTitle("Todos foram presos!")
         .setColor("RED")
         .setThumbnail('https://images-ext-2.discordapp.net/external/HnKfZj2LRMudBZjyMw5oVXz58suPFYPiWTZOHFV8Cjs/https/acegif.com/wp-content/gifs/police-car-94.gif')
         .setDescription(`Você foi preso na richa e levado para a prisão!\nE você perdeu um total de **R$${amount}**!`)
         .setFooter(`estatistica da prisão`);


         const filterr = (reaction, user) => {
            return ['🚔', '🚓', '👮'].includes(reaction.emoji.name) && user.id === message.author.id;
        }

         message.channel.send(`${autor}`, moneyEmbed).then(msg=>{
            msg.react("🚔")
            msg.react("🚓")
            msg.react("👮")
         


         db.subtract(`money_${message.guild.id}_${autor.id}`, amount);
         db.set(`prisao_${message.guild.id}_${autor.id}`, Date.now());


         const choicess = ['🚔', '🚓', '👮']
         const me = choicess[Math.floor(Math.random() * choicess.length)]
         msg.awaitReactions(filterr, {time: 10000, error: ["time"], max: 2}).then(
             async(collected) => {
                 const reaction = collected.first()
                 let result = new Discord.MessageEmbed()
                 .setTitle("Você foi preso")
                 .addField("Sua escolha", `${reaction.emoji.name}`)
                 .addField("Minha escolha", `${me}`)
             await msg.edit(moneyEmbed)
                 if ((me === "🚔" && reaction.emoji.name === "🚓") ||
                 (me === "👮" && reaction.emoji.name === "🚔") ||
                 (me === "🚓" && reaction.emoji.name === "👮")) {
                     message.reply("Você foi preso!");
             } else if (me === reaction.emoji.name) {
                 return message.reply("Você foi preso!");
             } else {
                 return message.reply("Você foi preso!");
             }
         })
         .catch(collected => {
            message.reply('Você está preso!');
        })
        })

    
        }else{


            

const choices = ['🐶', '🐺', '🦁']
const me = choices[Math.floor(Math.random() * choices.length)]
msg.awaitReactions(filter, {time: 10000, error: ["time"], max: 1}).then(
    async(collected) => {
        const reaction = collected.first()
        let result = new Discord.MessageEmbed()
        .setTitle("Resultado")
        .setColor("	#B0E0E6")
        .addField("Sua escolha:", `${reaction.emoji.name}`)
        .addField("Oponente:", `${me}`)
    await msg.edit(result)
        if ((me === "🐶" && reaction.emoji.name === "🐺") ||
        (me === "🦁" && reaction.emoji.name === "🐶") ||
        (me === "🐺" && reaction.emoji.name === "🦁")) {


            let lose = Math.floor(Math.random() * 180) + 8;
           
            let derrota = new Discord.MessageEmbed()
            .setTitle("Perdeu")
            .setColor("RED")
            .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/859955286609887242/Pngtreegangster_dog_vector_4768385.png?width=559&height=559')
            .setDescription(`${user}, essa aposta você perdeu um total de ${lose} moedas nesse round!`)
        
            message.reply(derrota);
            db.subtract(`money_${message.guild.id}_${autor.id}`, lose);
    } else if (me === reaction.emoji.name) {

        let empate = new Discord.MessageEmbed()
        .setTitle("Empate")
        .setColor("#48D1CC")
        .setThumbnail('https://media.discordapp.net/attachments/859982103639097374/860220049700421677/gn.png')
        .setDescription(`${user}, essa aposta foi um empate e você não ganhou e não perdeu nada!`)
    

        return message.reply(empate);
    } else {

        const randomAmountOfXp = Math.floor(Math.random() * 20) + 30;
            

        Levels.appendXp(message.author.id, message.guild.id, randomAmountOfXp);

           const userr = await Levels.fetch(message.author.id, message.guild.id);

        let amount = Math.floor(Math.random() * 650) + 250;
        let Ganhou = new Discord.MessageEmbed()
        .setTitle("Ganhou")
        .setColor("#00FF00")
        .setThumbnail('https://media.discordapp.net/attachments/859982103639097374/860304905596305428/Pngtree_1590871.png?width=559&height=559')
        .setDescription(`${user}, essa aposta você ganhou!\nE sua recompensa foi de:\n\n💰 **Moedas ganha:**\n${amount} moedas!\n\n<:unnamed:859596024334778398> **Xp ganho:** \n${randomAmountOfXp} experiência.\n\n<:levelup:859596052611989524> **level:** \n${userr.level}.`)
        message.channel.send(Ganhou)
        db.add(`money_${message.guild.id}_${autor.id}`, amount);

    }
})
.catch(collected => {
    message.reply('O comando foi cancelado porque você não respondeu a tempo!');
})


}

     })
})

})
}
}





