const Discord = require('discord.js');

exports.run = (client, message, args) => {
    let personPoke = message.mentions.members.first();
    let pokes = ['https://i.imgur.com/xApGHp4.gif?noredirect', 'https://i.gifer.com/S00v.gif', 'https://pa1.narvii.com/6946/d5b18a40da583b359f2e953c1c7abe27f4c28b21r1-600-338_hq.gif'];
    let pokesR = pokes[Math.floor(Math.random() * pokes.length)];
    let quote;
    let quoteR;
    if (!personPoke) {
        let personPoke = "nobody";

        let embed = new Discord.MessageEmbed()
            .setDescription(`**<@${message.author.id}> **cutucou** ${personPoke}!**`)
            .setImage(pokesR)
            .setColor("YELLOW");

        message.channel.send(embed);
        return;
    }

    let embed = new Discord.MessageEmbed()
        .setDescription(`**<@${message.author.id}> **cutucou** ${personPoke}!**`)
        .setImage(pokesR)
        .setColor("YELLOW");

    message.channel.send(embed);
}

exports.help = {
    enabled: true,
    hideHelp: false,
    type: "fun",
    name: "poke",
    description: "The `poke` command allows you to poke your friends!",
    usage: "`yabe poke <person to poke>`",
}