const Discord = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args) => {

  function convertMilliseconds(ms) {
    const seconds = ~~(ms/1000)
    const minutes = ~~(seconds/60)
    
    return { minutes: minutes%60, seconds: seconds%60 }
  }
  
  
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    let user = message.author;
    let author = await db.fetch(`hunt_${message.guild.id}_${user.id}`)

    let timeout = 606060;



    if (author !== null && timeout - (Date.now() - author) > 0) {
        let time = convertMilliseconds(timeout - (Date.now() -  author));
    

        message.channel.send(`**${member.user.tag}**, você já caçou recentemente, volte a caçar novamente em \`${time.minutes} Minutos, ${time.seconds} segundos\`.`)
      } else {


    let hunt = [
        "**🐰 `(Coelho)`**",
        "**🐸 `(Sapo)`**",
        "**🐒 `(Macaco)`**",
        "**🐔 `(Galinha)`**",
        "**🐤 `(Pintinho)`**",
        "**🐺 `(Lobo)`**",
        "**🐓 `(Galo)`**",
        "**🦃 `(Peru)`**", 
        "**🐿 `(Esquilo)`**",
        "**🐃 `(Búfalo Marinho)`**",
        "**🐂 `(Boi)`**",
        "**🐎 `( Cavalo Salvagem)`**",
        "**🐖 `(Porco)`**",
        "**🐍 `(Cobra)`**",
        "**🐄 `(Vaca)`**"
    ]

    const huntresult = Math.floor((Math.random() * hunt.length));
    let amount = Math.floor(Math.random() * 250) + 1;
        message.channel.send(`**Caçador:** - 🏹\n**${member.user.tag}** caçou um(a) ${hunt[huntresult]} e ganhou \`${amount}\` moedas com a caçada.`)

    db.add(`money_${message.guild.id}_${user.id}`, amount)
    db.set(`hunt_${message.guild.id}_${user.id}`, Date.now())

    };
    }


module.exports.help = {
  name:"hunt",
  aliases: []
}