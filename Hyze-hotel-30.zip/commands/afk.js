const Discord = require('discord.js')
const db = require('quick.db')
const config = require('../config.json')

module.exports.run = async (Client, message, args, prefix) => {

message.delete({ timeout: 1000 });

    let autor = message.author;


    let afk =  args.join(" ")

    const content = args.join(" ")

    let embed2 = new Discord.MessageEmbed()
    .setTitle("AUSENCIA!")
    .setColor("BLUE")
    .setDescription(`Você deve colocar o motivo de porque você vai se ausentar!`)


    if (!afk) {
        return message.channel.send(`${message.author}`, embed2)
    }else{

    
    if(!message.content.startsWith(config["Bot_Info"].prefix)) return;

    await db.set(`afk-${message.author.id}+${message.guild.id}`, content)


    let timeEmbed = new Discord.MessageEmbed()
    .setColor("#98FB98")
    .setThumbnail('https://media.discordapp.net/attachments/857060559132688414/860903536936878120/594816.png')
    .setDescription(`**AUSENTE:**\n${autor} você agora está ausente.\n\n**RAZÃO:** \n\`${content}\``);

    message.channel.send(timeEmbed)
    
}
}

module.exports.help = {
    name: `afk`,
    aliases: []
};