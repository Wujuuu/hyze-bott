const Discord = require('discord.js');

module.exports = {
  nome: 'servericon',
  alternativas: ['servericon'],
  run: async (client, message, args) => {
    var embed = {
      title: `🖼 Ícone Do servidor __**${message.guild.name}**__`,
      description: `:arrow_down: [Clique Aqui](${message.guild.iconURL({
        dynamic: true, format: "png", size: 4096
      })}) Para Baixar!.`,
      color: '#FFFF00',
      image: {
        url: message.guild.iconURL({ dynamic: true, format: "png", size: 4096 })
      }
    };
    message.reply({ embed: embed });
  }
};