const Levels = require("discord-xp");
const canvacord = require("canvacord");
const Discord = require('discord.js');


exports.run = async (client, message, args) => {
const target = message.mentions.users.first() || message.author; 

const user = await Levels.fetch(target.id, message.guild.id, true); 

const neededXp = Levels.xpFor(parseInt(user.level) + 1);

if (!user) return message.channel.send("Parece que você não ganhou nenhum XP até agora."); 



const rank = new canvacord.Rank()
.setAvatar(message.author.displayAvatarURL({dynamic: false, format: 'png'}))
.setCurrentXP(user.xp)
.setRequiredXP(neededXp)
.setStatus(message.author.presence.status, true, true)
.setRank(user.position)
.setLevel(user.level)
.setProgressBar("#FF00FF", "COLOR")
.setUsername(message.author.username)
.setDiscriminator(message.author.discriminator);

rank.build()
    .then(data => {
        const attachment = new Discord.MessageAttachment(data, "RankCard.png");
        message.channel.send(attachment);


    });

}