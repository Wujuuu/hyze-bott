const Discord = require ("discord.js")

module.exports = {
    name: "membros",
    description: "Mostra total de membros de um servidor!",
    author: "srrafah_ :))",

    run: async(client, message, args) => {

        let mencao = message.author;

        let msg = new Discord.MessageEmbed()
        .setTitle(`🍃 Membros desse servidor!`)
        .setDescription(`Olá!, ${message.author}, abaixo temos o numero de membros desse servidor!
        
        Atualmente em **${message.guild.name}** temos **${message.guild.memberCount}** membros!`)
        .setColor("YELLOW")
        .setThumbnail(message.guild.iconURL())
        message.channel.send(mencao, msg)
  
    }
}