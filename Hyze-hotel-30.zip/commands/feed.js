const client = require('nekos.life');
const Discord = require('discord.js')
const neko = new client();
module.exports = {
  name: "feed",
  category: "expressões",
  description: "alimenta um usuário mencionado",
  usage: "[command] + [user]",
  run: async (client, message, args) => {

      if (!message.member.permissions.has("SEND_TTS_MESSAGES"))
      return message.reply(
      "Apenas usuários vips podem usar esse comando."
      );
  
  //command

        const user = message.mentions.users.first();
        if(!user)
        return message.reply('Mencione alguém para alimentar');

        async function work() {
        let owo = (await neko.sfw.feed());

        const feedembed = new Discord.MessageEmbed()
        .setTitle(user.username + " Você foi alimentado! ")
        .setDescription((user.toString() + " foi alimentado por " + message.author.toString()))
        .setImage(owo.url)
        .setColor(`#000000`)
        .setURL(owo.url);
        message.channel.send(feedembed);

}

      work();
}
                };