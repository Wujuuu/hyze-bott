const Discord = require('discord.js')

module.exports.run = async (client, message, args) => {
    let clientping = new Date() - message.createdAt;

    message.channel.send(`${message.author}`)
    let embed = new Discord.MessageEmbed()
        .setTitle(":ping_pong:Pong")
        .addField(":robot:BOT: ", Math.floor(clientping) + "ms")
        .setFooter(`${message.author.tag}`, message.author.displayAvatarURL)
        .setColor("YELLOW")

        message.channel.send(embed)
}

module.exports.help = {
    name: "ping"
}