const { MessageEmbed, DiscordAPIError } = require("discord.js")
const cooldowns = {}
const ms = require("ms")

module.exports = {
  name: "bans",
  aliases: ["listban", "list-ban", "banimentos"],
  //by baliza hehehe :)
  run: async (client, message, args) => {
    message.delete();
    if(!cooldowns[message.author.id]) cooldowns[message.author.id] = {
      lastCmd: null
    }
  let ultimoCmd = cooldowns[message.author.id].lastCmd 
   let timeout = 10000
  if (ultimoCmd !== null && timeout- (Date.now() - ultimoCmd) > 0) {
  let time = ms(timeout - (Date.now() - ultimoCmd)); 
  let resta = [time.seconds, 'segundos']
  
  if(resta[0] == 0) resta = ['alguns', 'millisegundos']
  if(resta[0] == 1) resta = [time.seconds, 'segundo']
  const aguarde = new Discord.MessageEmbed()
  .setColor('BLACK')
  .setDescription(`<a:FDL_red_nao:856989015961108511> Por favor ${message.author}, espere \`${time}\` para executar outro comando`)
      message.channel.send(aguarde).then(msg=> {
          msg.delete({ timeout: 5000 });
          })
     return;
  } else {
               cooldowns[message.author.id].lastCmd = Date.now() 
  }

    if (!message.member.hasPermission("ADMINISTRATOR")) return message.inlineReply(`<a:FDL_red_nao:856989015961108511> Você não possui permissão de \`Administrador\` bobão!`)
   const bytokyo = message.guild.fetchBans()
   const tokyo_color = "BLACK"
   const tokyo_d = (await bytokyo).map((tokyo) => tokyo.user.tag).join("\n")  || "\`\`\`Ninguém foi banido\`\`\`"
    const bytokyo2 = new MessageEmbed()
    .setTitle('**Lista de banidos**')
    .setDescription(tokyo_d)
    .setColor(tokyo_color)
    .setFooter(`${client.user.username}#${client.user.discriminator}`, client.user.displayAvatarURL({dinamyc : true}))
    .setTimestamp(new Date())
    
    message.channel.send(bytokyo2).then(msg => msg.delete({timeout: 5000000}))
    //by tokyo hehehe :)
  }
  }