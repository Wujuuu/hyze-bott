const Discord = require('discord.js');
const db = require('quick.db');

exports.run = async (client, message, args) => {

  function convertMilliseconds(ms) {
   const seconds = ~~(ms/1000)
    const minutes = ~~(seconds/60)
    const hours = ~~(minutes/60)
    const days = ~~(hours/24)
    const months = ~~(days/30)
    const years = ~~(days/365)
  
    return { years, months: months%12 , days: days%30, hours: hours%24, minutes: minutes%60, seconds: seconds%60 }
  }

  let autor = message.author;

  let user = message.mentions.users.first() || client.users.cache.get(args[0]);

  if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para dar o respeito!');
  }

if(user.id == autor.id){
        return message.channel.send(` ${autor} você não pode dar respeito a si próprio!`);
    };

    let author = await db.fetch(`respeitos_${message.guild.id}_${user.id}`)

    let timeout = 600606000;
    
    if (author !== null && timeout - (Date.now() - author) > 0) {

    let time = convertMilliseconds(timeout - (Date.now() - author));
     message.channel.send(`${autor} Você já gastou seus respeitos, tente novamente em  \`${time.hours}h, ${time.minutes}m, ${time.seconds}s\`.`)
    } else {

  let sorte = Math.floor(Math.random() * 3) + 2;
    let amount = sorte;

    db.add(`respeito_${message.guild.id}_${user.id}`, amount);
    db.set(`respeitos_${message.guild.id}_${user.id}`, Date.now());

 let resp =`**Respeitado:** - :thumbsup:\n**Você deu ${amount} respeito para ${user}**`
      message.channel.send(resp)

}
}