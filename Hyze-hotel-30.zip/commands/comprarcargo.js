const Discord = require('discord.js')
const db = require('quick.db')

module.exports.run = async (client, message, args) => {

    let canal = client.channels.cache.get("855544094596399154")//id do canal
    
    let suprema = message.guild.roles.cache.get("855836534745989130");

    let ghost = message.guild.roles.cache.get("855836962396045324");

    let user = message.author;

    let items = await db.fetch(`items_${message.guild.id}_${message.author.id}`, {items: []})

    let author = db.fetch(`money_${message.guild.id}_${user.id}`)

    let Embed = new Discord.MessageEmbed()
    .setColor("#FFFFFF")
    .setDescription(`:x: você precisa de 250.000 moedas para comprar o cargo suprema.`);

    if (args[0] == 'suprema') {
        if (author < 250000) return message.channel.send(Embed)
        
        db.fetch(`suprema_${message.guild.id}_${user.id}`);
        db.set(`suprema_${message.guild.id}_${user.id}`, true)

        let Embed2 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`Você comprou o cargo **Suprema 👑** por 250.000 moedas.`);

        db.subtract(`money_${message.guild.id}_${user.id}`, 250000)
        db.push(`items_${message.guild.id}_${message.author.id}`, "Suprema 👑")
        message.member.roles.add(suprema.id);
        message.channel.send(Embed2)
    } else if(args[0] == 'vip') {
        let Embed2 = new Discord.MessageEmbed()
        .setColor("RED")
        .setDescription(`:x: Você precisa de \`500.000 moedas.\` para comprar vip.`);

        if (author < 500000) return message.channel.send(Embed2)
       
        db.fetch(`vip_${message.guild.id}_${user.id}`)
        db.add(`vip_${message.guild.id}_${user.id}`, 1)

        let Embed3 = new Discord.MessageEmbed()
        .setColor("GREEN")
        .setDescription(`:white_check_mark: Você comprou vip permanente por \`500.000 moedas.\``);

        db.subtract(`money_${message.guild.id}_${user.id}`, 500000)
        db.push(`items_${message.guild.id}_${message.author.id}`, "Vip 💠")
        message.channel.send(Embed3)
    } else if(args[0] == 'vaziooo') {
        let Embed2 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:x: você precisa de 800 moedas para comprar serpa custom.`);

        if (author < 800) return message.channel.send(Embed2)
       
        db.fetch(`serpa_${message.guild.id}_${user.id}`)
        db.add(`serpa_${message.guild.id}_${user.id}`, 1)

        let Embed3 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:white_check_mark: Você comprou **1 serpa custom** por 600 moedas.`);

        db.subtract(`money_${message.guild.id}_${user.id}`, 800)
        db.push(`items_${message.guild.id}_${message.author.id}`, "serpa custom")
        message.channel.send(Embed3)
    } else if(args[0] == 'ghost') {
        let Embed2 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:x: você precisa de 150.000 moedas para comprar o cargo ghost`);
    
        if (author < 150000) return message.channel.send(Embed2)
       
        db.fetch(`ghost_${message.guild.id}_${user.id}`)
        db.add(`ghost_${message.guild.id}_${user.id}`, 1)
        
        let Embed3 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(`:white_check_mark: Você comprou o cargo **Ghost ** por 150.000 moedas.`);
    
        db.subtract(`money_${message.guild.id}_${user.id}`, 150000)
        db.push(`items_${message.guild.id}_${message.author.id}`, "Ghost 👻")
        message.member.roles.add(ghost.id);
        message.channel.send(Embed3)
    } else {
        let embed3 = new Discord.MessageEmbed()
        .setColor("#FFFFFF")
        .setDescription(':x: selecione 1 item da loja para ser comprado.')
        message.channel.send(embed3)
    }

    
    const log1 = new Discord.MessageEmbed()
    .setTitle(`Loja Log`)
    .setColor("#ffff00")
    .setThumbnail(`${message.author.displayAvatarURL({dynamic: true})}`)
    .setDescription(`Novo item adquirido.`)
    .addField("Autor:", message.author)
    .addField("Item:", `${args[0]}`)
     canal.send(log1).catch(console.error);

}

  
  module.exports.help = {
    name:"buy",
    aliases: [""]
  }